#!/usr/bin/env python3
"""
Backend API Testing for Project Arise
Tests all backend endpoints following the specified test flow
"""

import requests
import json
import sys
from datetime import datetime

# Backend URL from environment
BACKEND_URL = "https://level-self-2.preview.emergentagent.com/api"

# Test credentials
TEST_EMAIL = "test@arise.com"
TEST_PASSWORD = "test123"
TEST_USERNAME = "TestHunter"

# Global variables to store test data
auth_token = None
user_id = None
mission_id = None
initial_xp = 0
initial_level = 1
initial_streak = 0

def print_test_header(test_name):
    """Print formatted test header"""
    print(f"\n{'='*80}")
    print(f"TEST: {test_name}")
    print(f"{'='*80}")

def print_success(message):
    """Print success message"""
    print(f"✅ SUCCESS: {message}")

def print_error(message):
    """Print error message"""
    print(f"❌ FAILED: {message}")

def print_info(message):
    """Print info message"""
    print(f"ℹ️  INFO: {message}")

def test_register():
    """Test 1: Register a new user"""
    global auth_token, user_id, initial_xp, initial_level, initial_streak
    
    print_test_header("User Registration")
    
    # First, try to clean up any existing test user (optional)
    print_info(f"Attempting to register user: {TEST_EMAIL}")
    
    payload = {
        "username": TEST_USERNAME,
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/auth/register", json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            auth_token = data.get('token')
            user_data = data.get('user')
            user_id = user_data.get('id')
            initial_xp = user_data.get('xp', 0)
            initial_level = user_data.get('level', 1)
            initial_streak = user_data.get('streak', 0)
            
            print_success(f"User registered successfully")
            print_info(f"User ID: {user_id}")
            print_info(f"Username: {user_data.get('username')}")
            print_info(f"Email: {user_data.get('email')}")
            print_info(f"Level: {initial_level}, XP: {initial_xp}, Rank: {user_data.get('rank')}")
            print_info(f"Arc: {user_data.get('current_arc')}")
            print_info(f"Token received: {auth_token[:20]}...")
            return True
        elif response.status_code == 400:
            # User might already exist, try login instead
            print_info("User already exists, will use login instead")
            return test_login()
        else:
            print_error(f"Registration failed with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during registration: {str(e)}")
        return False

def test_login():
    """Test 2: Login with existing credentials"""
    global auth_token, user_id, initial_xp, initial_level, initial_streak
    
    print_test_header("User Login")
    
    payload = {
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/auth/login", json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            auth_token = data.get('token')
            user_data = data.get('user')
            user_id = user_data.get('id')
            initial_xp = user_data.get('xp', 0)
            initial_level = user_data.get('level', 1)
            initial_streak = user_data.get('streak', 0)
            
            print_success(f"User logged in successfully")
            print_info(f"User ID: {user_id}")
            print_info(f"Username: {user_data.get('username')}")
            print_info(f"Level: {initial_level}, XP: {initial_xp}, Rank: {user_data.get('rank')}")
            print_info(f"Streak: {initial_streak}")
            print_info(f"Token received: {auth_token[:20]}...")
            return True
        else:
            print_error(f"Login failed with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during login: {str(e)}")
        return False

def test_get_user_profile():
    """Test 3: Get user profile with JWT token"""
    print_test_header("Get User Profile (/api/auth/me)")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    
    try:
        response = requests.get(f"{BACKEND_URL}/auth/me", headers=headers, timeout=10)
        
        if response.status_code == 200:
            user_data = response.json()
            print_success("User profile fetched successfully")
            print_info(f"Username: {user_data.get('username')}")
            print_info(f"Email: {user_data.get('email')}")
            print_info(f"Level: {user_data.get('level')}, XP: {user_data.get('xp')}")
            print_info(f"Rank: {user_data.get('rank')}, Arc: {user_data.get('current_arc')}")
            print_info(f"Streak: {user_data.get('streak')}")
            print_info(f"Total Missions Completed: {user_data.get('total_missions_completed')}")
            return True
        else:
            print_error(f"Failed to fetch profile with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during profile fetch: {str(e)}")
        return False

def test_get_motivational_quote():
    """Test 4: Get daily motivational quote"""
    print_test_header("Get Motivational Quote (/api/quote)")
    
    try:
        response = requests.get(f"{BACKEND_URL}/quote", timeout=10)
        
        if response.status_code == 200:
            quote_data = response.json()
            print_success("Motivational quote fetched successfully")
            print_info(f"Quote: \"{quote_data.get('quote')}\"")
            print_info(f"Author: {quote_data.get('author')}")
            return True
        else:
            print_error(f"Failed to fetch quote with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during quote fetch: {str(e)}")
        return False

def test_get_daily_missions():
    """Test 5: Get daily missions (should generate 3-5 missions)"""
    global mission_id
    
    print_test_header("Get Daily Missions (/api/missions/daily)")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    
    try:
        response = requests.get(f"{BACKEND_URL}/missions/daily", headers=headers, timeout=10)
        
        if response.status_code == 200:
            missions = response.json()
            print_success(f"Daily missions fetched successfully")
            print_info(f"Number of missions: {len(missions)}")
            
            if len(missions) < 3 or len(missions) > 5:
                print_error(f"Expected 3-5 missions, got {len(missions)}")
                return False
            
            for i, mission in enumerate(missions, 1):
                print_info(f"\nMission {i}:")
                print_info(f"  ID: {mission.get('id')}")
                print_info(f"  Title: {mission.get('title')}")
                print_info(f"  Description: {mission.get('description')}")
                print_info(f"  Category: {mission.get('category')}")
                print_info(f"  XP Reward: {mission.get('xp_reward')}")
                print_info(f"  Difficulty: {mission.get('difficulty_level')}")
                print_info(f"  Completed: {mission.get('completed')}")
                
                # Store first mission ID for completion test
                if i == 1:
                    mission_id = mission.get('id')
            
            return True
        else:
            print_error(f"Failed to fetch missions with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during missions fetch: {str(e)}")
        return False

def test_complete_mission():
    """Test 6: Complete one mission"""
    print_test_header("Complete Mission (/api/missions/complete)")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    if not mission_id:
        print_error("No mission ID available")
        return False
    
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    
    payload = {
        "mission_id": mission_id
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/missions/complete", json=payload, headers=headers, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            print_success("Mission completed successfully")
            print_info(f"XP Gained: {result.get('xp_gained')}")
            print_info(f"New XP: {result.get('new_xp')}")
            print_info(f"New Level: {result.get('new_level')}")
            print_info(f"Leveled Up: {result.get('leveled_up')}")
            print_info(f"New Rank: {result.get('new_rank')}")
            print_info(f"New Arc: {result.get('new_arc')}")
            print_info(f"New Streak: {result.get('new_streak')}")
            
            # Verify XP increased
            if result.get('new_xp') <= initial_xp:
                print_error(f"XP did not increase! Initial: {initial_xp}, New: {result.get('new_xp')}")
                return False
            
            return True
        else:
            print_error(f"Failed to complete mission with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during mission completion: {str(e)}")
        return False

def test_verify_profile_updates():
    """Test 7: Verify XP, level, and streak are updated correctly"""
    print_test_header("Verify Profile Updates After Mission Completion")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    
    try:
        response = requests.get(f"{BACKEND_URL}/auth/me", headers=headers, timeout=10)
        
        if response.status_code == 200:
            user_data = response.json()
            print_success("Profile fetched after mission completion")
            
            new_xp = user_data.get('xp')
            new_level = user_data.get('level')
            new_streak = user_data.get('streak')
            total_missions = user_data.get('total_missions_completed')
            
            print_info(f"Initial XP: {initial_xp}, New XP: {new_xp}")
            print_info(f"Initial Level: {initial_level}, New Level: {new_level}")
            print_info(f"Initial Streak: {initial_streak}, New Streak: {new_streak}")
            print_info(f"Total Missions Completed: {total_missions}")
            
            # Verify XP increased
            if new_xp <= initial_xp:
                print_error(f"XP did not increase!")
                return False
            
            # Verify total missions increased
            if total_missions < 1:
                print_error(f"Total missions completed should be at least 1")
                return False
            
            print_success("All profile updates verified correctly")
            return True
        else:
            print_error(f"Failed to fetch profile with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during profile verification: {str(e)}")
        return False

def test_complete_same_mission_again():
    """Test 8: Try to complete the same mission again (should fail)"""
    print_test_header("Try to Complete Same Mission Again (Should Fail)")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    if not mission_id:
        print_error("No mission ID available")
        return False
    
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    
    payload = {
        "mission_id": mission_id
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/missions/complete", json=payload, headers=headers, timeout=10)
        
        if response.status_code == 400:
            error_data = response.json()
            if "already completed" in error_data.get('detail', '').lower():
                print_success("Correctly prevented duplicate mission completion")
                print_info(f"Error message: {error_data.get('detail')}")
                return True
            else:
                print_error(f"Got 400 but wrong error message: {error_data.get('detail')}")
                return False
        elif response.status_code == 200:
            print_error("Mission was completed again! This should not be allowed")
            return False
        else:
            print_error(f"Unexpected status code {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during duplicate completion test: {str(e)}")
        return False

def test_get_missions_again():
    """Test 9: Get daily missions again (completed mission should show as completed)"""
    print_test_header("Get Daily Missions Again (Verify Completion Status)")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    
    try:
        response = requests.get(f"{BACKEND_URL}/missions/daily", headers=headers, timeout=10)
        
        if response.status_code == 200:
            missions = response.json()
            print_success(f"Daily missions fetched again")
            print_info(f"Number of missions: {len(missions)}")
            
            completed_count = 0
            for mission in missions:
                if mission.get('id') == mission_id:
                    if mission.get('completed'):
                        print_success(f"Mission {mission_id[:8]}... is correctly marked as completed")
                        completed_count += 1
                    else:
                        print_error(f"Mission {mission_id[:8]}... should be marked as completed but isn't")
                        return False
                
                print_info(f"Mission: {mission.get('title')} - Completed: {mission.get('completed')}")
            
            if completed_count == 0:
                print_error("Could not find the completed mission in the list")
                return False
            
            return True
        else:
            print_error(f"Failed to fetch missions with status {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print_error(f"Exception during missions fetch: {str(e)}")
        return False

def run_all_tests():
    """Run all backend tests in sequence"""
    print("\n" + "="*80)
    print("PROJECT ARISE - BACKEND API TESTING")
    print("="*80)
    print(f"Backend URL: {BACKEND_URL}")
    print(f"Test User: {TEST_EMAIL}")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = {}
    
    # Test 1 & 2: Register or Login
    results['register_or_login'] = test_register()
    
    if results['register_or_login']:
        # Test 3: Get user profile
        results['get_profile'] = test_get_user_profile()
        
        # Test 4: Get motivational quote
        results['get_quote'] = test_get_motivational_quote()
        
        # Test 5: Get daily missions
        results['get_missions'] = test_get_daily_missions()
        
        # Test 6: Complete mission
        if results['get_missions']:
            results['complete_mission'] = test_complete_mission()
            
            # Test 7: Verify profile updates
            if results['complete_mission']:
                results['verify_updates'] = test_verify_profile_updates()
                
                # Test 8: Try to complete same mission again
                results['duplicate_completion'] = test_complete_same_mission_again()
                
                # Test 9: Get missions again
                results['get_missions_again'] = test_get_missions_again()
    
    # Print summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    total_tests = len(results)
    passed_tests = sum(1 for result in results.values() if result)
    
    for test_name, result in results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed_tests}/{total_tests} tests passed")
    print(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    # Return exit code
    return 0 if passed_tests == total_tests else 1

if __name__ == "__main__":
    exit_code = run_all_tests()
    sys.exit(exit_code)
