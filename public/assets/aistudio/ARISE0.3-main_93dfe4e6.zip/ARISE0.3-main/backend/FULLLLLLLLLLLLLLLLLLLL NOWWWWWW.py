# backend/progression.py
# Progression helpers extracted from server.py to keep server.py clean
# and to permanently eliminate Pylance/VS Code false-positive parser errors.

from datetime import datetime, timedelta, timezone


# ---------- Rank & Arc ----------

RANK_THRESHOLDS = [
    (1,  "E"),
    (10, "D"),
    (20, "C"),
    (30, "B"),
    (40, "A"),
    (50, "S"),
]

ARC_THRESHOLDS = [
    (1,  "Awakening Arc"),
    (10, "Hunter Arc"),
    (25, "Shadow Monarch Arc"),
    (40, "Ascension Arc"),
    (50, "Sovereign Arc"),
]


def calculate_rank(level: int) -> str:
    rank = "E"
    for threshold, name in RANK_THRESHOLDS:
        if level >= threshold:
            rank = name
    return rank


def calculate_arc(level: int) -> str:
    arc = "Awakening Arc"
    for threshold, name in ARC_THRESHOLDS:
        if level >= threshold:
            arc = name
    return arc


# ---------- XP curve ----------

def xp_for_level(level: int) -> int:
    """XP required to advance FROM `level` to `level + 1`."""
    if level < 1:
        level = 1
    return 100 * level * level


def calculate_level_from_xp(total_xp: int) -> int:
    """Inverse of xp_for_level — derives the current level from cumulative XP."""
    if total_xp < 0:
        total_xp = 0
    level = 1
    remaining = total_xp
    while remaining >= xp_for_level(level):
        remaining -= xp_for_level(level)
        level += 1
    return level


# ---------- Main progression applier ----------

async def apply_progression(db, user: dict, xp_gained: int, increment_missions: bool = True) -> dict:
    """
    Apply an XP gain to a user document and persist to MongoDB.

    Args:
        db: Motor async database handle (db = client[DB_NAME])
        user: the user dict already loaded from db.users
        xp_gained: XP to add (>= 0)
        increment_missions: if True, bumps total_missions_completed and updates streak

    Returns:
        {
            success, xp_gained, new_xp, new_level,
            leveled_up, new_rank, new_arc, new_streak
        }
    """
    if xp_gained is None or xp_gained < 0:
        xp_gained = 0

    old_level = int(user.get("level", 1) or 1)
    old_xp    = int(user.get("xp", 0) or 0)

    new_total_xp = old_xp + xp_gained
    new_level    = calculate_level_from_xp(new_total_xp)
    leveled_up   = new_level > old_level
    new_rank     = calculate_rank(new_level)
    new_arc      = calculate_arc(new_level)

    # ---- Streak ----
    today = datetime.now(timezone.utc).date()
    last_raw = user.get("last_completion_date")
    last_date = None
    if isinstance(last_raw, datetime):
        last_date = last_raw.date()
    elif isinstance(last_raw, str) and last_raw:
        try:
            last_date = datetime.fromisoformat(last_raw).date()
        except ValueError:
            last_date = None

    current_streak = int(user.get("streak", 0) or 0)

    if not increment_missions:
        new_streak = current_streak
    elif last_date is None:
        new_streak = 1
    elif last_date == today:
        new_streak = current_streak if current_streak > 0 else 1
    elif last_date == today - timedelta(days=1):
        new_streak = current_streak + 1
    else:
        new_streak = 1

    # ---- Persist ----
    set_doc = {
        "xp": new_total_xp,
        "level": new_level,
        "rank": new_rank,
        "current_arc": new_arc,
        "streak": new_streak,
    }
    if increment_missions:
        set_doc["last_completion_date"] = datetime.combine(
            today, datetime.min.time()
        ).replace(tzinfo=timezone.utc)

    update_query = {"$set": set_doc}
    if increment_missions:
        update_query["$inc"] = {"total_missions_completed": 1}

    await db.users.update_one({"id": user["id"]}, update_query)

    return {
        "success": True,
        "xp_gained": xp_gained,
        "new_xp": new_total_xp,
        "new_level": new_level,
        "leveled_up": leveled_up,
        "new_rank": new_rank,
        "new_arc": new_arc,
        "new_streak": new_streak,
    }