"""Backend regression tests for Project Arise UX upgrades.

Covers:
- Auth (register/login/me) with new theme_color & avatar_style fields
- Profile updates (PUT /api/auth/profile) with validation
- Missions (GET /api/missions/daily) with format/duration_seconds/started_at
- Timer flow (POST /api/missions/start, POST /api/missions/complete)
- Progress stats (GET /api/progress/stats)
"""
import os
import uuid
import time
import requests
import pytest

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL").rstrip("/")


# -------------------- Health --------------------
class TestHealth:
    def test_root_api_alive(self, api_client):
        r = api_client.get(f"{BASE_URL}/api/", timeout=10)
        assert r.status_code == 200
        assert "message" in r.json()


# -------------------- Auth --------------------
class TestAuth:
    def test_login_seeded_user_success(self, api_client):
        r = api_client.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "test@arise.com", "password": "test123"},
            timeout=15,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert "token" in body
        assert "user" in body
        user = body["user"]
        # new fields must be returned with defaults
        assert user.get("theme_color") in ("cyan", "crimson", "violet", "gold", "emerald")
        assert user.get("avatar_style") in ("shadow", "crimson", "frost", "storm", "void", "solar")

    def test_login_wrong_password(self, api_client):
        r = api_client.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "test@arise.com", "password": "wrongpass"},
            timeout=10,
        )
        assert r.status_code == 401

    def test_me_returns_theme_and_avatar(self, api_client, auth_headers):
        r = api_client.get(f"{BASE_URL}/api/auth/me", headers=auth_headers, timeout=10)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "theme_color" in body
        assert "avatar_style" in body
        assert body["email"] == "test@arise.com"

    def test_register_new_user_has_defaults(self, api_client):
        suffix = uuid.uuid4().hex[:8]
        payload = {
            "username": f"TEST_user_{suffix}",
            "email": f"TEST_{suffix}@arise.com",
            "password": "test123",
        }
        r = api_client.post(f"{BASE_URL}/api/auth/register", json=payload, timeout=15)
        assert r.status_code == 200, r.text
        user = r.json()["user"]
        assert user["theme_color"] == "cyan"
        assert user["avatar_style"] == "shadow"


# -------------------- Profile updates --------------------
class TestProfileUpdate:
    def test_update_valid_theme_and_avatar(self, api_client, auth_headers):
        # Set a known good combination
        r = api_client.put(
            f"{BASE_URL}/api/auth/profile",
            headers=auth_headers,
            json={"theme_color": "violet", "avatar_style": "frost"},
            timeout=10,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["theme_color"] == "violet"
        assert body["avatar_style"] == "frost"

        # Verify persistence via /me
        me = api_client.get(f"{BASE_URL}/api/auth/me", headers=auth_headers, timeout=10).json()
        assert me["theme_color"] == "violet"
        assert me["avatar_style"] == "frost"

        # Restore defaults so tests are idempotent
        api_client.put(
            f"{BASE_URL}/api/auth/profile",
            headers=auth_headers,
            json={"theme_color": "cyan", "avatar_style": "shadow"},
            timeout=10,
        )

    def test_update_invalid_theme_color_rejected(self, api_client, auth_headers):
        r = api_client.put(
            f"{BASE_URL}/api/auth/profile",
            headers=auth_headers,
            json={"theme_color": "purple"},
            timeout=10,
        )
        assert r.status_code == 400
        assert "theme" in r.json().get("detail", "").lower()

    def test_update_invalid_avatar_style_rejected(self, api_client, auth_headers):
        r = api_client.put(
            f"{BASE_URL}/api/auth/profile",
            headers=auth_headers,
            json={"avatar_style": "dragon"},
            timeout=10,
        )
        assert r.status_code == 400
        assert "avatar" in r.json().get("detail", "").lower()

    def test_update_username_duplicate_rejected(self, api_client, auth_headers):
        # Create a second user with a known username
        suffix = uuid.uuid4().hex[:8]
        other_username = f"TEST_taken_{suffix}"
        reg = api_client.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "username": other_username,
                "email": f"TEST_{suffix}@arise.com",
                "password": "test123",
            },
            timeout=15,
        )
        assert reg.status_code == 200, reg.text

        # Try to take that username on the seeded user
        r = api_client.put(
            f"{BASE_URL}/api/auth/profile",
            headers=auth_headers,
            json={"username": other_username},
            timeout=10,
        )
        assert r.status_code == 400
        assert "username" in r.json().get("detail", "").lower()

    def test_update_username_too_short_rejected(self, api_client, auth_headers):
        r = api_client.put(
            f"{BASE_URL}/api/auth/profile",
            headers=auth_headers,
            json={"username": "ab"},
            timeout=10,
        )
        assert r.status_code == 400


# -------------------- Missions --------------------
class TestMissionsDaily:
    def test_daily_missions_shape(self, api_client, auth_headers):
        r = api_client.get(f"{BASE_URL}/api/missions/daily", headers=auth_headers, timeout=15)
        assert r.status_code == 200, r.text
        missions = r.json()
        assert isinstance(missions, list)
        assert len(missions) >= 1
        for m in missions:
            for field in (
                "id",
                "title",
                "description",
                "xp_reward",
                "difficulty_level",
                "category",
                "completed",
                "mission_type",
                "format",
                "duration_seconds",
            ):
                assert field in m, f"Mission missing field {field}: {m}"
            assert m["format"] in ("timed", "instant")
            # timed missions should have a positive duration; instant should be 0
            if m["format"] == "timed":
                assert m["duration_seconds"] > 0
            else:
                assert m["duration_seconds"] == 0
            # started_at present (may be None)
            assert "started_at" in m


def _get_missions(api_client, auth_headers):
    r = api_client.get(f"{BASE_URL}/api/missions/daily", headers=auth_headers, timeout=15)
    assert r.status_code == 200
    return r.json()


def _find_mission(missions, *, fmt, completed=False):
    for m in missions:
        if m["format"] == fmt and m["completed"] == completed:
            return m
    return None


class TestTimedMissionFlow:
    def test_start_timed_mission_and_idempotency(self, api_client, auth_headers):
        missions = _get_missions(api_client, auth_headers)
        timed = _find_mission(missions, fmt="timed", completed=False)
        if not timed:
            pytest.skip("No incomplete timed mission available today")

        # First start
        r1 = api_client.post(
            f"{BASE_URL}/api/missions/start",
            headers=auth_headers,
            json={"mission_id": timed["id"]},
            timeout=10,
        )
        assert r1.status_code == 200, r1.text
        b1 = r1.json()
        assert b1["success"] is True
        assert "started_at" in b1
        assert b1["duration_seconds"] == timed["duration_seconds"]
        first_already = b1.get("already_started", False)

        # Second start should be idempotent
        r2 = api_client.post(
            f"{BASE_URL}/api/missions/start",
            headers=auth_headers,
            json={"mission_id": timed["id"]},
            timeout=10,
        )
        assert r2.status_code == 200, r2.text
        b2 = r2.json()
        assert b2["already_started"] is True
        # started_at must not effectively change between calls.
        # Allow sub-second drift caused by Mongo datetime rounding to ms.
        from datetime import datetime as _dt
        t1 = _dt.fromisoformat(b1["started_at"])
        t2 = _dt.fromisoformat(b2["started_at"])
        assert abs((t2 - t1).total_seconds()) < 0.01, (
            f"started_at changed on duplicate start: {b1['started_at']} -> {b2['started_at']}"
        )

        # Confirm GET /missions/daily reflects started_at
        missions_after = _get_missions(api_client, auth_headers)
        same = next((m for m in missions_after if m["id"] == timed["id"]), None)
        assert same is not None
        assert same["started_at"] is not None
        # Mark stored result for the next test if needed
        TestTimedMissionFlow._idempotent_first_already = first_already  # noqa

    def test_complete_timed_mission_before_timer_returns_400(self, api_client, auth_headers):
        missions = _get_missions(api_client, auth_headers)
        timed = _find_mission(missions, fmt="timed", completed=False)
        if not timed:
            pytest.skip("No incomplete timed mission available today")

        # Ensure it has been started (idempotent so safe to call again)
        api_client.post(
            f"{BASE_URL}/api/missions/start",
            headers=auth_headers,
            json={"mission_id": timed["id"]},
            timeout=10,
        )

        # Immediately try to complete it
        r = api_client.post(
            f"{BASE_URL}/api/missions/complete",
            headers=auth_headers,
            json={"mission_id": timed["id"]},
            timeout=10,
        )
        # Should reject - timer must elapse first
        assert r.status_code == 400, f"Expected 400 but got {r.status_code}: {r.text}"
        detail = r.json().get("detail", "")
        assert "remaining" in detail.lower() or "timer" in detail.lower()
        # Mission must still be NOT completed
        missions_after = _get_missions(api_client, auth_headers)
        same = next((m for m in missions_after if m["id"] == timed["id"]), None)
        assert same is not None
        assert same["completed"] is False

    def test_complete_timed_mission_without_start_returns_400(self, api_client, auth_headers):
        """A fresh timed mission that has never been started should reject completion."""
        # We can't easily create a brand new timed mission today (daily missions
        # are generated once), so we register a new user, pull their daily
        # missions, and try to complete a timed one without starting it.
        suffix = uuid.uuid4().hex[:8]
        reg = api_client.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "username": f"TEST_timed_{suffix}",
                "email": f"TEST_timed_{suffix}@arise.com",
                "password": "test123",
            },
            timeout=15,
        )
        assert reg.status_code == 200
        token = reg.json()["token"]
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}

        missions = api_client.get(
            f"{BASE_URL}/api/missions/daily", headers=headers, timeout=15
        ).json()
        timed = next((m for m in missions if m["format"] == "timed"), None)
        if not timed:
            pytest.skip("Random daily mission pool produced no timed missions for new user")

        r = api_client.post(
            f"{BASE_URL}/api/missions/complete",
            headers=headers,
            json={"mission_id": timed["id"]},
            timeout=10,
        )
        assert r.status_code == 400
        detail = r.json().get("detail", "").lower()
        assert "start" in detail or "timer" in detail


class TestInstantMissionFlow:
    def test_complete_instant_mission_succeeds(self, api_client, auth_headers):
        missions = _get_missions(api_client, auth_headers)
        instant = _find_mission(missions, fmt="instant", completed=False)
        if not instant:
            pytest.skip("No incomplete instant mission available today")

        r = api_client.post(
            f"{BASE_URL}/api/missions/complete",
            headers=auth_headers,
            json={"mission_id": instant["id"]},
            timeout=10,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["success"] is True
        assert body["xp_gained"] == instant["xp_reward"]
        assert "new_xp" in body
        assert "new_level" in body

        # Verify persistence: mission should now be completed
        missions_after = _get_missions(api_client, auth_headers)
        same = next((m for m in missions_after if m["id"] == instant["id"]), None)
        assert same is not None
        assert same["completed"] is True

    def test_start_on_instant_mission_returns_400(self, api_client, auth_headers):
        """Starting a timer on an instant-format mission should be rejected."""
        missions = _get_missions(api_client, auth_headers)
        instant = _find_mission(missions, fmt="instant", completed=False)
        if not instant:
            # Try completed ones too — server checks completed first, so use any instant
            instant = next((m for m in missions if m["format"] == "instant"), None)
        if not instant:
            pytest.skip("No instant mission available")

        r = api_client.post(
            f"{BASE_URL}/api/missions/start",
            headers=auth_headers,
            json={"mission_id": instant["id"]},
            timeout=10,
        )
        # If the mission was already completed, server returns 400 "already completed".
        # If not completed, it returns 400 "cannot be started with a timer".
        assert r.status_code == 400


# -------------------- Progress Stats --------------------
class TestProgressStats:
    def test_stats_shape(self, api_client, auth_headers):
        r = api_client.get(f"{BASE_URL}/api/progress/stats", headers=auth_headers, timeout=10)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "daily_stats" in body
        assert "week_total_missions" in body
        assert "week_total_xp" in body
        assert "consistency_percentage" in body
        assert isinstance(body["daily_stats"], list)
        assert len(body["daily_stats"]) == 7
        for d in body["daily_stats"]:
            assert "date" in d
            assert "missions_completed" in d
            assert "xp_gained" in d
            assert isinstance(d["missions_completed"], int)
            assert isinstance(d["xp_gained"], int)
        assert 0 <= body["consistency_percentage"] <= 100
        # Totals should be non-negative ints
        assert body["week_total_missions"] >= 0
        assert body["week_total_xp"] >= 0

    def test_stats_requires_auth(self, api_client):
        r = api_client.get(f"{BASE_URL}/api/progress/stats", timeout=10)
        assert r.status_code in (401, 403)

    def test_stats_reflects_completion(self, api_client, auth_headers):
        """After completing an instant mission, week totals should increase."""
        before = api_client.get(
            f"{BASE_URL}/api/progress/stats", headers=auth_headers, timeout=10
        ).json()

        missions = _get_missions(api_client, auth_headers)
        instant = _find_mission(missions, fmt="instant", completed=False)
        if not instant:
            pytest.skip("No incomplete instant mission to drive stats delta")

        comp = api_client.post(
            f"{BASE_URL}/api/missions/complete",
            headers=auth_headers,
            json={"mission_id": instant["id"]},
            timeout=10,
        )
        assert comp.status_code == 200, comp.text
        gained = comp.json()["xp_gained"]

        # small delay to ensure write is reflected
        time.sleep(0.5)
        after = api_client.get(
            f"{BASE_URL}/api/progress/stats", headers=auth_headers, timeout=10
        ).json()
        assert after["week_total_missions"] == before["week_total_missions"] + 1
        assert after["week_total_xp"] == before["week_total_xp"] + gained
