from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timedelta
import bcrypt
import jwt
import random

ROOT_DIR = Path(__file__).parent
load_dotenv(dotenv_path=".env")

# MongoDB connection
mongo_url = os.environ.get("MONGO_URL")
print("Mongo URL loaded:", mongo_url[:30])
client = AsyncIOMotorClient(
    mongo_url,
    tls=True,
    tlsAllowInvalidCertificates=True,
    serverSelectionTimeoutMS=30000,
    connectTimeoutMS=30000,
    socketTimeoutMS=30000,
    retryWrites=True
)
db = client[os.environ['DB_NAME']]

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24 * 30  # 30 days

security = HTTPBearer()

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# ============ MODELS ============

class UserRegister(BaseModel):
    username: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    level: int
    xp: int
    rank: str
    current_arc: str
    streak: int
    total_missions_completed: int
    last_login: datetime
    theme_color: str = "cyan"
    avatar_style: str = "default"
    background_style: str = "tuff"

class TokenResponse(BaseModel):
    token: str
    user: UserResponse

class MissionResponse(BaseModel):
    id: str
    title: str
    description: str
    xp_reward: int
    difficulty_level: float
    category: str
    completed: bool
    mission_type: str
    format: str = "instant"
    duration_seconds: int = 0
    started_at: Optional[datetime] = None

class MissionComplete(BaseModel):
    mission_id: str

class MissionStart(BaseModel):
    mission_id: str

class ProfileUpdate(BaseModel):
    theme_color: Optional[str] = None
    avatar_style: Optional[str] = None
    username: Optional[str] = None
    background_style: Optional[str] = None

class QuoteResponse(BaseModel):
    quote: str
    author: str

class DailyStat(BaseModel):
    date: str
    missions_completed: int
    xp_gained: int

class StatsResponse(BaseModel):
    daily_stats: List[DailyStat]
    week_total_missions: int
    week_total_xp: int
    consistency_percentage: int

# ============ MOTIVATIONAL QUOTES ============

MOTIVATIONAL_QUOTES = [
    {"quote": "The only way to do great work is to love what you do.", "author": "Steve Jobs"},
    {"quote": "Success is not final, failure is not fatal.", "author": "Winston Churchill"},
    {"quote": "Believe you can and you're halfway there.", "author": "Theodore Roosevelt"},
    {"quote": "The future belongs to those who believe in the beauty of their dreams.", "author": "Eleanor Roosevelt"},
    {"quote": "It does not matter how slowly you go as long as you do not stop.", "author": "Confucius"},
    {"quote": "Everything you've ever wanted is on the other side of fear.", "author": "George Addair"},
    {"quote": "Believe in yourself. You are braver than you think.", "author": "Unknown"},
    {"quote": "I am not a product of my circumstances. I am a product of my decisions.", "author": "Stephen Covey"},
    {"quote": "The only impossible journey is the one you never begin.", "author": "Tony Robbins"},
    {"quote": "Your limitation—it's only your imagination.", "author": "Unknown"},
    {"quote": "Push yourself, because no one else is going to do it for you.", "author": "Unknown"},
    {"quote": "Great things never come from comfort zones.", "author": "Unknown"},
    {"quote": "Dream it. Wish it. Do it.", "author": "Unknown"},
    {"quote": "Success doesn't just find you. You have to go out and get it.", "author": "Unknown"},
    {"quote": "The harder you work for something, the greater you'll feel when you achieve it.", "author": "Unknown"},
    {"quote": "Wake up with determination. Go to bed with satisfaction.", "author": "Unknown"},
    {"quote": "Do something today that your future self will thank you for.", "author": "Unknown"},
    {"quote": "Little things make big days.", "author": "Unknown"},
    {"quote": "Don't stop when you're tired. Stop when you're done.", "author": "Unknown"},
    {"quote": "The only limit to our realization of tomorrow is our doubts of today.", "author": "Franklin D. Roosevelt"},
]

# ============ MISSION TEMPLATES ============

MISSION_TEMPLATES = [
    {
        "mission_type": "pushups",
        "title": "Pushup Challenge",
        "description": "Complete {count} pushups",
        "base_difficulty": 5,
        "increment": 5,
        "xp_base": 20,
        "category": "strength",
        "format": "instant"
    },
    {
        "mission_type": "pullups",
        "title": "Pullup Power",
        "description": "Complete {count} pullups (assisted is okay!)",
        "base_difficulty": 1,
        "increment": 2,
        "xp_base": 30,
        "category": "strength",
        "format": "instant"
    },
    {
        "mission_type": "situps",
        "title": "Core Crusher",
        "description": "Complete {count} situps",
        "base_difficulty": 10,
        "increment": 5,
        "xp_base": 15,
        "category": "strength",
        "format": "instant"
    },
    {
        "mission_type": "running",
        "title": "Cardio Quest",
        "description": "Run or jog for {count} minutes",
        "base_difficulty": 10,
        "increment": 5,
        "xp_base": 25,
        "category": "cardio",
        "format": "timed",
        "duration_unit": "minutes"
    },
    {
        "mission_type": "walking",
        "title": "Walking Journey",
        "description": "Walk for {count} minutes",
        "base_difficulty": 10,
        "increment": 5,
        "xp_base": 15,
        "category": "cardio",
        "format": "timed",
        "duration_unit": "minutes"
    },
    {
        "mission_type": "water",
        "title": "Hydration Mission",
        "description": "Drink {count}L of water today",
        "base_difficulty": 1,
        "increment": 0.5,
        "xp_base": 20,
        "category": "health",
        "format": "instant"
    },
    {
        "mission_type": "study",
        "title": "Knowledge Seeker",
        "description": "Study or learn for {count} minutes",
        "base_difficulty": 15,
        "increment": 10,
        "xp_base": 30,
        "category": "discipline",
        "format": "instant"
    },
    {
        "mission_type": "meditation",
        "title": "Mindful Warrior",
        "description": "Meditate for {count} minutes",
        "base_difficulty": 5,
        "increment": 5,
        "xp_base": 25,
        "category": "mental",
        "format": "timed",
        "duration_unit": "minutes"
    },
    {
        "mission_type": "sleep",
        "title": "Rest & Recover",
        "description": "Sleep before midnight and get {count} hours of sleep",
        "base_difficulty": 7,
        "increment": 0.5,
        "xp_base": 20,
        "category": "health",
        "format": "timed",
        "duration_unit": "hours"
    },
]

# ============ HELPER FUNCTIONS ============

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    payload = decode_token(token)
    user_id = payload.get('user_id')
    
    user = await db.users.find_one({'id': user_id})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    return user

def calculate_rank(level: int) -> str:
    if level <= 10:
        return "E"
    elif level <= 20:
        return "D"
    elif level <= 30:
        return "C"
    elif level <= 40:
        return "B"
    elif level <= 50:
        return "A"
    else:
        return "S"

def calculate_arc(level: int) -> str:
    if level <= 10:
        return "Awakening Arc"
    elif level <= 25:
        return "Discipline Arc"
    elif level <= 40:
        return "Warrior Arc"
    elif level <= 55:
        return "Elite Arc"
    else:
        return "Monarch Arc"

def xp_for_level(level: int) -> int:
    """Calculate XP needed to reach the next level"""
    return 100 * level

def calculate_level_from_xp(xp: int) -> tuple:
    """Returns (level, current_level_xp, xp_needed_for_next_level)"""
    level = 1
    total_xp_for_level = 0
    
    while True:
        xp_needed = xp_for_level(level)
        if total_xp_for_level + xp_needed > xp:
            current_level_xp = xp - total_xp_for_level
            return level, current_level_xp, xp_needed
        total_xp_for_level += xp_needed
        level += 1

def get_mission_difficulty(mission_type: str, user_level: int, completions: int) -> float:
    """Calculate difficulty based on user progression"""
    template = next((m for m in MISSION_TEMPLATES if m['mission_type'] == mission_type), None)
    if not template:
        return 1
    
    # Increase difficulty every 3-5 completions
    progression_tier = completions // 4
    difficulty = template['base_difficulty'] + (template['increment'] * progression_tier)
    
    return difficulty

async def check_and_update_streak(user_id: str):
    """Check and update user streak based on last mission completion"""
    user = await db.users.find_one({'id': user_id})
    if not user:
        return
    
    last_mission = await db.user_missions.find_one(
        {'user_id': user_id, 'completed': True},
        sort=[('completed_at', -1)]
    )
    
    if not last_mission:
        return
    
    last_completed = last_mission.get('completed_at')
    if not last_completed:
        return
    
    # Calculate days since last completion
    now = datetime.utcnow()
    days_diff = (now - last_completed).days
    
    if days_diff > 1:
        # Streak broken
        await db.users.update_one(
            {'id': user_id},
            {'$set': {'streak': 0}}
        )

# ============ API ROUTES ============

@api_router.post("/auth/register", response_model=TokenResponse)
async def register(user_data: UserRegister):
    # Check if user exists
    existing_user = await db.users.find_one({'email': user_data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    existing_username = await db.users.find_one({'username': user_data.username})
    if existing_username:
        raise HTTPException(status_code=400, detail="Username already taken")
    
    # Create new user
    user_id = str(uuid.uuid4())
    hashed_pwd = hash_password(user_data.password)
    
    user = {
        'id': user_id,
        'username': user_data.username,
        'email': str(user_data.email),
        'password': hashed_pwd,
        'level': 1,
        'xp': 0,
        'rank': 'E',
        'current_arc': 'Awakening Arc',
        'streak': 0,
        'total_missions_completed': 0,
        'theme_color': 'cyan',
        'avatar_style': 'default',
        'background_style': 'tuff',
        'created_at': datetime.utcnow(),
        'last_login': datetime.utcnow()
    }
    
    try:
        await db.users.insert_one(user)
    except Exception as e:
        print("REGISTER ERROR:", str(e))
        raise HTTPException(status_code=500, detail=str(e))

    # Create token
    token = create_token(user_id)

    user_response = UserResponse(
        id=user['id'],
        username=user['username'],
        email=user['email'],
        level=user['level'],
        xp=user['xp'],
        rank=user['rank'],
        current_arc=user['current_arc'],
        streak=user['streak'],
        total_missions_completed=user['total_missions_completed'],
        last_login=user['last_login'],
        theme_color=user.get('theme_color', 'cyan'),
        avatar_style=user.get('avatar_style', 'default'),
        background_style=user.get('background_style', 'tuff'),
    )

    return TokenResponse(token=token, user=user_response)

@api_router.post("/auth/login", response_model=TokenResponse)
async def login(login_data: UserLogin):
    user = await db.users.find_one({'email': str(login_data.email)})
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    if not verify_password(login_data.password, user['password']):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Update last login
    await db.users.update_one(
        {'id': user['id']},
        {'$set': {'last_login': datetime.utcnow()}}
    )
    
    # Create token
    token = create_token(user['id'])
    
    user_response = UserResponse(
        id=user['id'],
        username=user['username'],
        email=user['email'],
        level=user['level'],
        xp=user['xp'],
        rank=user['rank'],
        current_arc=user['current_arc'],
        streak=user['streak'],
        total_missions_completed=user['total_missions_completed'],
        last_login=user['last_login'],
        theme_color=user.get('theme_color', 'cyan'),
      avatar_style=user.get('avatar_style', 'default'),
        background_style=user.get('background_style', 'tuff'),
    )
    
    return TokenResponse(token=token, user=user_response)

@api_router.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    return UserResponse(
        id=current_user['id'],
        username=current_user['username'],
        email=current_user['email'],
        level=current_user['level'],
        xp=current_user['xp'],
        rank=current_user['rank'],
        current_arc=current_user['current_arc'],
        streak=current_user['streak'],
        total_missions_completed=current_user['total_missions_completed'],
        last_login=current_user['last_login'],
        theme_color=current_user.get('theme_color', 'cyan'),
        avatar_style=current_user.get('avatar_style', 'default'),
        background_style=current_user.get('background_style', 'tuff'),
    )

@api_router.put("/auth/profile", response_model=UserResponse)
async def update_profile(
    data: ProfileUpdate,
    current_user: dict = Depends(get_current_user),
):
    user_id = current_user['id']
    updates: dict = {}

    if data.theme_color is not None:
        if data.theme_color not in ['cyan', 'crimson', 'violet', 'gold', 'emerald']:
            raise HTTPException(status_code=400, detail="Invalid theme color")
        updates['theme_color'] = data.theme_color

    if data.avatar_style is not None:
        if data.avatar_style not in ['default', 'avatar', 'rise', 'arise']:
            raise HTTPException(status_code=400, detail="Invalid avatar style")
        updates['avatar_style'] = data.avatar_style

    if data.background_style is not None:
        if data.background_style not in ['tuff', 'violet']:
            raise HTTPException(status_code=400, detail="Invalid background style")
        updates['background_style'] = data.background_style

    if data.username is not None:
        new_username = data.username.strip()
        if len(new_username) < 3:
            raise HTTPException(status_code=400, detail="Username must be at least 3 characters")
        if new_username != current_user['username']:
            existing = await db.users.find_one({'username': new_username})
            if existing:
                raise HTTPException(status_code=400, detail="Username already taken")
            updates['username'] = new_username

    if updates:
        await db.users.update_one({'id': user_id}, {'$set': updates})

    updated_user = await db.users.find_one({'id': user_id})
    return UserResponse(
        id=updated_user['id'],
        username=updated_user['username'],
        email=updated_user['email'],
        level=updated_user['level'],
        xp=updated_user['xp'],
        rank=updated_user['rank'],
        current_arc=updated_user['current_arc'],
        streak=updated_user['streak'],
        total_missions_completed=updated_user['total_missions_completed'],
        last_login=updated_user['last_login'],
        theme_color=updated_user.get('theme_color', 'cyan'),
        avatar_style=updated_user.get('avatar_style', 'default'),
        background_style=updated_user.get('background_style', 'tuff'),
    )

@api_router.get("/missions/daily", response_model=List[MissionResponse])
async def get_daily_missions(current_user: dict = Depends(get_current_user)):
    user_id = current_user['id']
    today = datetime.utcnow().date()
    
    # Check if missions already generated for today
    existing_missions = await db.user_missions.find({
        'user_id': user_id,
        'assigned_date': {'$gte': datetime.combine(today, datetime.min.time())}
    }).to_list(100)
    
    if existing_missions:
        missions = []
        for mission in existing_missions:
            template = next((m for m in MISSION_TEMPLATES if m['mission_type'] == mission['mission_type']), None)
            if template:
                # Backfill missing format/duration_seconds for legacy missions
                needs_update = {}
                if mission.get('format') is None:
                    mission['format'] = template.get('format', 'instant')
                    needs_update['format'] = mission['format']
                if mission.get('duration_seconds') in (None, 0) and mission['format'] == 'timed':
                    unit = template.get('duration_unit', 'minutes')
                    difficulty = mission.get('difficulty_level') or template['base_difficulty']
                    if unit == 'minutes':
                        mission['duration_seconds'] = int(difficulty * 60)
                    elif unit == 'hours':
                        mission['duration_seconds'] = int(difficulty * 3600)
                    needs_update['duration_seconds'] = mission['duration_seconds']
                if needs_update:
                    await db.user_missions.update_one({'id': mission['id']}, {'$set': needs_update})
                
                missions.append(MissionResponse(
                    id=mission['id'],
                    title=mission['title'],
                    description=mission['description'],
                    xp_reward=mission['xp_reward'],
                    difficulty_level=mission['difficulty_level'],
                    category=mission['category'],
                    completed=mission['completed'],
                    mission_type=mission['mission_type'],
                    format=mission.get('format', 'instant'),
                    duration_seconds=mission.get('duration_seconds', 0) or 0,
                    started_at=mission.get('started_at')
                ))
        return missions
    
    # Generate new missions (3-5 random missions)
    num_missions = random.randint(3, 5)
    selected_templates = random.sample(MISSION_TEMPLATES, min(num_missions, len(MISSION_TEMPLATES)))
    
    missions = []
    for template in selected_templates:
        # Get user's completion count for this mission type
        completion_count = await db.user_missions.count_documents({
            'user_id': user_id,
            'mission_type': template['mission_type'],
            'completed': True
        })
        
        difficulty = get_mission_difficulty(template['mission_type'], current_user['level'], completion_count)
        
        # Format description with difficulty
        if template['mission_type'] in ['water', 'sleep']:
            description = template['description'].format(count=difficulty)
        else:
            description = template['description'].format(count=int(difficulty))
        
        # Calculate duration_seconds for timed missions
        duration_seconds = 0
        mission_format = template.get('format', 'instant')
        if mission_format == 'timed':
            unit = template.get('duration_unit', 'minutes')
            if unit == 'minutes':
                duration_seconds = int(difficulty * 60)
            elif unit == 'hours':
                duration_seconds = int(difficulty * 3600)
        
        mission_id = str(uuid.uuid4())
        mission = {
            'id': mission_id,
            'user_id': user_id,
            'mission_type': template['mission_type'],
            'title': template['title'],
            'description': description,
            'xp_reward': template['xp_base'] + (completion_count * 5),
            'difficulty_level': difficulty,
            'category': template['category'],
            'format': mission_format,
            'duration_seconds': duration_seconds,
            'started_at': None,
            'completed': False,
            'assigned_date': datetime.utcnow(),
            'completed_at': None
        }
        
        await db.user_missions.insert_one(mission)
        
        missions.append(MissionResponse(
            id=mission['id'],
            title=mission['title'],
            description=mission['description'],
            xp_reward=mission['xp_reward'],
            difficulty_level=mission['difficulty_level'],
            category=mission['category'],
            completed=mission['completed'],
            mission_type=mission['mission_type'],
            format=mission['format'],
            duration_seconds=mission['duration_seconds'],
            started_at=mission['started_at']
        ))
    
    return missions

@api_router.post("/missions/start")
async def start_mission(data: MissionStart, current_user: dict = Depends(get_current_user)):
    user_id = current_user['id']
    mission = await db.user_missions.find_one({'id': data.mission_id, 'user_id': user_id})
    if not mission:
        raise HTTPException(status_code=404, detail="Mission not found")
    
    if mission['completed']:
        raise HTTPException(status_code=400, detail="Mission already completed")
    
    if mission.get('format', 'instant') != 'timed':
        raise HTTPException(status_code=400, detail="This mission cannot be started with a timer")
    
    # If already started, return current state (prevent accidental reset)
    if mission.get('started_at'):
        return {
            'success': True,
            'started_at': mission['started_at'].isoformat(),
            'duration_seconds': mission.get('duration_seconds', 0),
            'already_started': True
        }
    
    now = datetime.utcnow()
    await db.user_missions.update_one(
        {'id': data.mission_id},
        {'$set': {'started_at': now}}
    )
    
    return {
        'success': True,
        'started_at': now.isoformat(),
        'duration_seconds': mission.get('duration_seconds', 0),
        'already_started': False
    }

@api_router.post("/missions/complete")
async def complete_mission(data: MissionComplete, current_user: dict = Depends(get_current_user)):
    user_id = current_user['id']
    mission_id = data.mission_id
    
    # Find mission
    mission = await db.user_missions.find_one({'id': mission_id, 'user_id': user_id})
    if not mission:
        raise HTTPException(status_code=404, detail="Mission not found")
    
    if mission['completed']:
        raise HTTPException(status_code=400, detail="Mission already completed")
    
    # For timed missions, ensure the timer has fully elapsed
    if mission.get('format') == 'timed':
        if not mission.get('started_at'):
            raise HTTPException(status_code=400, detail="Start the mission timer first")
        elapsed = (datetime.utcnow() - mission['started_at']).total_seconds()
        if elapsed < mission.get('duration_seconds', 0):
            remaining = int(mission.get('duration_seconds', 0) - elapsed)
            raise HTTPException(status_code=400, detail=f"Timer still running. {remaining}s remaining.")
    
    # Mark mission as completed
    await db.user_missions.update_one(
        {'id': mission_id},
        {'$set': {'completed': True, 'completed_at': datetime.utcnow()}}
    )
    
    # Update user XP and stats
    new_xp = current_user['xp'] + mission['xp_reward']
    new_level, current_level_xp, xp_needed = calculate_level_from_xp(new_xp)
    new_rank = calculate_rank(new_level)
    new_arc = calculate_arc(new_level)
    
    # Update streak
    today = datetime.utcnow().date()
    last_mission = await db.user_missions.find_one(
        {'user_id': user_id, 'completed': True, 'id': {'$ne': mission_id}},
        sort=[('completed_at', -1)]
    )
    
    new_streak = current_user['streak']
    if last_mission and last_mission.get('completed_at'):
        last_date = last_mission['completed_at'].date()
        days_diff = (today - last_date).days
        if days_diff == 1:
            new_streak += 1
        elif days_diff == 0:
            new_streak = current_user['streak']  # Same day
        else:
            new_streak = 1  # Streak broken, start fresh
    else:
        new_streak = 1  # First mission
    
    # Update user
    await db.users.update_one(
        {'id': user_id},
        {
            '$set': {
                'xp': new_xp,
                'level': new_level,
                'rank': new_rank,
                'current_arc': new_arc,
                'streak': new_streak
            },
            '$inc': {'total_missions_completed': 1}
        }
    )
    
    # Check if leveled up
    leveled_up = new_level > current_user['level']
    
    return {
        'success': True,
        'xp_gained': mission['xp_reward'],
        'new_xp': new_xp,
        'new_level': new_level,
        'leveled_up': leveled_up,
        'new_rank': new_rank,
        'new_arc': new_arc,
        'new_streak': new_streak
    }

@api_router.get("/progress/stats", response_model=StatsResponse)
async def get_progress_stats(current_user: dict = Depends(get_current_user)):
    user_id = current_user['id']
    today = datetime.utcnow().date()
    
    daily_stats = []
    week_total_missions = 0
    week_total_xp = 0
    active_days = 0
    
    for i in range(6, -1, -1):  # last 7 days, oldest to newest
        day = today - timedelta(days=i)
        day_start = datetime.combine(day, datetime.min.time())
        day_end = day_start + timedelta(days=1)
        
        completed_missions = await db.user_missions.find({
            'user_id': user_id,
            'completed': True,
            'completed_at': {'$gte': day_start, '$lt': day_end}
        }).to_list(1000)
        
        count = len(completed_missions)
        xp = sum(m.get('xp_reward', 0) for m in completed_missions)
        
        if count > 0:
            active_days += 1
        
        week_total_missions += count
        week_total_xp += xp
        
        daily_stats.append(DailyStat(
            date=day.isoformat(),
            missions_completed=count,
            xp_gained=xp
        ))
    
    consistency_percentage = int((active_days / 7) * 100)
    
    return StatsResponse(
        daily_stats=daily_stats,
        week_total_missions=week_total_missions,
        week_total_xp=week_total_xp,
        consistency_percentage=consistency_percentage
    )

@api_router.get("/quote", response_model=QuoteResponse)
async def get_daily_quote():
    quote = random.choice(MOTIVATIONAL_QUOTES)
    return QuoteResponse(**quote)

@api_router.get("/")
async def root():
    return {"message": "Project Arise API"}

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
