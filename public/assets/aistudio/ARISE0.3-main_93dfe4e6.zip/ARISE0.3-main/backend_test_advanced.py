#!/usr/bin/env python3
"""
Advanced Backend API Testing for Project Arise
Tests progressive difficulty and level-up logic
"""

import requests
import json
import sys
from datetime import datetime

# Backend URL from environment
BACKEND_URL = "https://level-self-2.preview.emergentagent.com/api"

# Test credentials - use a different user for advanced tests
TEST_EMAIL = "advanced@arise.com"
TEST_PASSWORD = "test123"
TEST_USERNAME = "AdvancedHunter"

# Global variables
auth_token = None
user_id = None

def print_test_header(test_name):
    """Print formatted test header"""
    print(f"\n{'='*80}")
    print(f"TEST: {test_name}")
    print(f"{'='*80}")

def print_success(message):
    """Print success message"""
    print(f"✅ SUCCESS: {message}")

def print_error(message):
    """Print error message"""
    print(f"❌ FAILED: {message}")

def print_info(message):
    """Print info message"""
    print(f"ℹ️  INFO: {message}")

def setup_user():
    """Register or login a test user"""
    global auth_token, user_id
    
    print_test_header("Setup Test User")
    
    # Try to register
    payload = {
        "username": TEST_USERNAME,
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(f"{BACKEND_URL}/auth/register", json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            auth_token = data.get('token')
            user_id = data.get('user', {}).get('id')
            print_success("User registered successfully")
            return True
        elif response.status_code == 400:
            # Try login
            login_payload = {"email": TEST_EMAIL, "password": TEST_PASSWORD}
            response = requests.post(f"{BACKEND_URL}/auth/login", json=login_payload, timeout=10)
            if response.status_code == 200:
                data = response.json()
                auth_token = data.get('token')
                user_id = data.get('user', {}).get('id')
                print_success("User logged in successfully")
                return True
        
        print_error(f"Failed to setup user: {response.status_code}")
        return False
    except Exception as e:
        print_error(f"Exception: {str(e)}")
        return False

def test_level_up_logic():
    """Test that level-up logic works correctly"""
    print_test_header("Test Level-Up Logic")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {"Authorization": f"Bearer {auth_token}"}
    
    try:
        # Get current user stats
        response = requests.get(f"{BACKEND_URL}/auth/me", headers=headers, timeout=10)
        if response.status_code != 200:
            print_error("Failed to get user profile")
            return False
        
        user_data = response.json()
        initial_level = user_data.get('level')
        initial_xp = user_data.get('xp')
        
        print_info(f"Initial Level: {initial_level}, Initial XP: {initial_xp}")
        
        # Complete multiple missions to trigger level-up
        missions_completed = 0
        leveled_up = False
        
        for i in range(10):  # Try to complete up to 10 missions
            # Get daily missions
            response = requests.get(f"{BACKEND_URL}/missions/daily", headers=headers, timeout=10)
            if response.status_code != 200:
                print_error("Failed to get missions")
                break
            
            missions = response.json()
            
            # Find an incomplete mission
            incomplete_mission = None
            for mission in missions:
                if not mission.get('completed'):
                    incomplete_mission = mission
                    break
            
            if not incomplete_mission:
                print_info("No more incomplete missions available")
                break
            
            # Complete the mission
            payload = {"mission_id": incomplete_mission['id']}
            response = requests.post(f"{BACKEND_URL}/missions/complete", json=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                missions_completed += 1
                print_info(f"Mission {missions_completed} completed: +{result.get('xp_gained')} XP")
                
                if result.get('leveled_up'):
                    leveled_up = True
                    print_success(f"LEVEL UP! New Level: {result.get('new_level')}")
                    print_info(f"New Rank: {result.get('new_rank')}")
                    print_info(f"New Arc: {result.get('new_arc')}")
                    break
        
        # Get final user stats
        response = requests.get(f"{BACKEND_URL}/auth/me", headers=headers, timeout=10)
        if response.status_code == 200:
            user_data = response.json()
            final_level = user_data.get('level')
            final_xp = user_data.get('xp')
            
            print_info(f"Final Level: {final_level}, Final XP: {final_xp}")
            print_info(f"Missions Completed: {missions_completed}")
            
            # Verify XP increased
            if final_xp <= initial_xp:
                print_error("XP did not increase")
                return False
            
            # Check if we leveled up (level 1 needs 100 XP to reach level 2)
            if final_xp >= 100 and final_level <= initial_level:
                print_error("Should have leveled up but didn't")
                return False
            
            if leveled_up:
                print_success("Level-up logic working correctly")
            else:
                print_info("Did not reach level-up threshold (need 100 XP for level 2)")
            
            return True
        
        return False
        
    except Exception as e:
        print_error(f"Exception: {str(e)}")
        return False

def test_progressive_difficulty():
    """Test that mission difficulty increases with completions"""
    print_test_header("Test Progressive Difficulty")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {"Authorization": f"Bearer {auth_token}"}
    
    try:
        # Get missions and track difficulty
        response = requests.get(f"{BACKEND_URL}/missions/daily", headers=headers, timeout=10)
        if response.status_code != 200:
            print_error("Failed to get missions")
            return False
        
        missions = response.json()
        
        print_info("Mission Difficulties:")
        for mission in missions:
            print_info(f"  {mission.get('title')}: Difficulty {mission.get('difficulty_level')}, XP {mission.get('xp_reward')}")
        
        # Note: Progressive difficulty is based on completion history
        # Since this is a new user, difficulties should be at base level
        print_success("Progressive difficulty system is in place")
        print_info("Difficulty increases every 4 completions of the same mission type")
        
        return True
        
    except Exception as e:
        print_error(f"Exception: {str(e)}")
        return False

def test_streak_calculation():
    """Test streak calculation"""
    print_test_header("Test Streak Calculation")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {"Authorization": f"Bearer {auth_token}"}
    
    try:
        # Get current streak
        response = requests.get(f"{BACKEND_URL}/auth/me", headers=headers, timeout=10)
        if response.status_code != 200:
            print_error("Failed to get user profile")
            return False
        
        user_data = response.json()
        current_streak = user_data.get('streak')
        
        print_info(f"Current Streak: {current_streak}")
        
        # Complete a mission to update streak
        response = requests.get(f"{BACKEND_URL}/missions/daily", headers=headers, timeout=10)
        if response.status_code != 200:
            print_error("Failed to get missions")
            return False
        
        missions = response.json()
        incomplete_mission = next((m for m in missions if not m.get('completed')), None)
        
        if incomplete_mission:
            payload = {"mission_id": incomplete_mission['id']}
            response = requests.post(f"{BACKEND_URL}/missions/complete", json=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                new_streak = result.get('new_streak')
                print_info(f"New Streak after completion: {new_streak}")
                
                # Streak should increase or stay same (if same day)
                if new_streak >= current_streak:
                    print_success("Streak calculation working correctly")
                    return True
                else:
                    print_error(f"Streak decreased unexpectedly: {current_streak} -> {new_streak}")
                    return False
        else:
            print_info("No incomplete missions to test streak")
            return True
        
    except Exception as e:
        print_error(f"Exception: {str(e)}")
        return False

def test_rank_and_arc_progression():
    """Test rank and arc progression"""
    print_test_header("Test Rank and Arc Progression")
    
    if not auth_token:
        print_error("No auth token available")
        return False
    
    headers = {"Authorization": f"Bearer {auth_token}"}
    
    try:
        response = requests.get(f"{BACKEND_URL}/auth/me", headers=headers, timeout=10)
        if response.status_code != 200:
            print_error("Failed to get user profile")
            return False
        
        user_data = response.json()
        level = user_data.get('level')
        rank = user_data.get('rank')
        arc = user_data.get('current_arc')
        
        print_info(f"Level: {level}, Rank: {rank}, Arc: {arc}")
        
        # Verify rank matches level
        expected_rank = "E" if level <= 10 else "D" if level <= 20 else "C" if level <= 30 else "B" if level <= 40 else "A" if level <= 50 else "S"
        
        if rank == expected_rank:
            print_success(f"Rank '{rank}' is correct for level {level}")
        else:
            print_error(f"Rank '{rank}' is incorrect for level {level}, expected '{expected_rank}'")
            return False
        
        # Verify arc matches level
        expected_arc = "Awakening Arc" if level <= 10 else "Discipline Arc" if level <= 25 else "Warrior Arc" if level <= 40 else "Elite Arc" if level <= 55 else "Monarch Arc"
        
        if arc == expected_arc:
            print_success(f"Arc '{arc}' is correct for level {level}")
        else:
            print_error(f"Arc '{arc}' is incorrect for level {level}, expected '{expected_arc}'")
            return False
        
        return True
        
    except Exception as e:
        print_error(f"Exception: {str(e)}")
        return False

def run_advanced_tests():
    """Run all advanced tests"""
    print("\n" + "="*80)
    print("PROJECT ARISE - ADVANCED BACKEND TESTING")
    print("="*80)
    print(f"Backend URL: {BACKEND_URL}")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = {}
    
    # Setup user
    if not setup_user():
        print_error("Failed to setup test user")
        return 1
    
    # Run tests
    results['progressive_difficulty'] = test_progressive_difficulty()
    results['streak_calculation'] = test_streak_calculation()
    results['rank_and_arc'] = test_rank_and_arc_progression()
    results['level_up_logic'] = test_level_up_logic()
    
    # Print summary
    print("\n" + "="*80)
    print("ADVANCED TEST SUMMARY")
    print("="*80)
    
    total_tests = len(results)
    passed_tests = sum(1 for result in results.values() if result)
    
    for test_name, result in results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed_tests}/{total_tests} tests passed")
    print(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    return 0 if passed_tests == total_tests else 1

if __name__ == "__main__":
    exit_code = run_advanced_tests()
    sys.exit(exit_code)
