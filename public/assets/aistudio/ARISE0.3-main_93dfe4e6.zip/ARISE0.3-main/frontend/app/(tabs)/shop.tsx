// ============================================================================
// PROJECT ARISE - SHOP SCREEN
// Futuristic anime-style shop with hidden affiliate links
// Solo Leveling / Cyber Hunter aesthetic
// ============================================================================

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  Linking,
  StyleSheet,
  Dimensions,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { PRODUCTS } from './PRODUCTS';

// ============================================================================
// PRODUCT DATA
// Edit titles, descriptions, images, and URLs here
// ============================================================================

export interface Product {
  id: number;
  title: string;
  description: string;
  image: string | any;
  url: string;
}

// ============================================================================
// MAIN SHOP SCREEN COMPONENT
// ============================================================================

export default function ShopScreen() {
  // Handle product card press - opens hidden URL
  const handleProductPress = async (product: Product) => {
    try {
      const canOpen = await Linking.canOpenURL(product.url);
      if (canOpen) {
        await Linking.openURL(product.url);
      } else {
        Alert.alert('Error', 'Unable to open this link');
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong');
      console.error('Linking error:', error);
    }
  };

  return (
    <View style={styles.container}>
      {/* Header Section */}
      <LinearGradient
        colors={['#0a0a0a', '#1a1a2e']}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>HUNTER SHOP</Text>
        <Text style={styles.headerSubtitle}>Gear Up for Your Missions</Text>
      </LinearGradient>

      {/* Scrollable Product Grid */}
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {PRODUCTS.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onPress={() => handleProductPress(product)}
          />
        ))}

        {/* Bottom Spacer */}
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

// ============================================================================
// PRODUCT CARD COMPONENT
// Reusable card with futuristic glow effect
// ============================================================================

interface ProductCardProps {
  product: Product;
  onPress: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onPress }) => {
  return (
    <TouchableOpacity
      style={styles.cardContainer}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {/* Glowing Border Effect */}
      <LinearGradient
        colors={['#00d4ff', '#7b2ff7', '#00d4ff']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.cardGlow}
      >
        {/* Inner Card Content */}
        <View style={styles.cardInner}>
          {/* Product Image */}
          <Image
            source={product.image}
            style={styles.productImage}
            resizeMode="cover"
          />

          {/* Product Info */}
          <View style={styles.productInfo}>
            <Text style={styles.productTitle}>{product.title}</Text>
            <Text style={styles.productDescription}>{product.description}</Text>

            {/* Call to Action */}
            <View style={styles.ctaContainer}>
              <LinearGradient
                colors={['#00d4ff', '#7b2ff7']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.ctaButton}
              >
                <Text style={styles.ctaText}>VIEW ITEM</Text>
              </LinearGradient>
            </View>
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
};

// ============================================================================
// STYLES
// Futuristic dark theme with neon accents
// ============================================================================

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 32;

const styles = StyleSheet.create({
  // Main Container
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },

  // Header Styles
  header: {
    paddingTop: 60,
    paddingBottom: 24,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 212, 255, 0.3)',
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '900',
    color: '#00d4ff',
    letterSpacing: 2,
    textShadowColor: '#00d4ff',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#888',
    marginTop: 4,
    letterSpacing: 1,
  },

  // Scroll View
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },

  // Product Card Container
  cardContainer: {
    marginBottom: 20,
    width: CARD_WIDTH,
  },

  // Glowing Border Gradient
  cardGlow: {
    borderRadius: 16,
    padding: 2, // Border thickness
  },

  // Inner Card
  cardInner: {
    backgroundColor: '#1a1a2e',
    borderRadius: 14,
    overflow: 'hidden',
  },

  // Product Image
  productImage: {
    width: '100%',
    height: 200,
    backgroundColor: '#0f0f1e',
  },

  // Product Info Section
  productInfo: {
    padding: 16,
  },
  productTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  productDescription: {
    fontSize: 14,
    color: '#aaaaaa',
    lineHeight: 20,
    marginBottom: 16,
  },

  // Call to Action Button
  ctaContainer: {
    alignItems: 'center',
  },
  ctaButton: {
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
  },
  ctaText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#ffffff',
    letterSpacing: 1.5,
  },

  // Bottom Spacer
  bottomSpacer: {
    height: 40,
  },
});