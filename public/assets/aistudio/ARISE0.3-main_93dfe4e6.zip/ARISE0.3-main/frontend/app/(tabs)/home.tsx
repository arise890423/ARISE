import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from '../../src/context/AuthContext';
import { Ionicons } from '@expo/vector-icons';
import { HunterAvatar } from '../../src/components/HunterAvatar';
import { getThemeColor, getRankColor } from '../../src/utils/theme';

const BACKEND_URL = "https://project-arise-1.onrender.com";

export default function Home() {
  const { user, token, updateUser } = useAuth();
  const router = useRouter();
  const theme = getThemeColor(user?.theme_color);
  const [quote, setQuote] = useState({ quote: '', author: '' });
  const [refreshing, setRefreshing] = useState(false);
  const [fadeAnim] = useState(new Animated.Value(0));

  useEffect(() => {
    loadQuote();
    if (token) fetchUserData();

    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  }, [token]);

  const loadQuote = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/quote`);
      if (response.ok) {
        const data = await response.json();
        setQuote(data);
      }
    } catch (error) {
      console.error('Error loading quote:', error);
    }
  };

  const fetchUserData = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/me`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
if (response.ok) {
        const data = await response.json();
        // [PATCH] Stale-backend protection — mirror of missions.tsx.
        // /api/auth/me sometimes briefly returns the PREVIOUS XP/level
        // snapshot right after a mission completes (read-replica lag,
        // write not yet visible, etc.). Blindly trusting it would roll
        // back the just-awarded XP on next app open / pull-to-refresh.
        // Accept the backend payload only when it is at least as
        // up-to-date as our local user:
        //   • backend level > local level   OR
        //   • backend xp    >= local xp
        // Otherwise ignore — AuthContext already hydrated us from the
        // latest local snapshot, which is the freshest source of truth.
        const localXp: number = user?.xp ?? 0;
        const localLevel: number = user?.level ?? 1;
        const backendXp: number =
          typeof data?.xp === 'number' ? data.xp : 0;
        const backendLevel: number =
          typeof data?.level === 'number' ? data.level : 1;
        const accept =
          backendLevel > localLevel || backendXp >= localXp;
        console.log(
          '[home] /auth/me stale-check →',
          'localXp=', localXp,
          'backendXp=', backendXp,
          'localLevel=', localLevel,
          'backendLevel=', backendLevel,
          'accepted=', accept,
        );
        if (accept) {
          await updateUser(data);
        }
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadQuote(), fetchUserData()]);
    setRefreshing(false);
  };

  const calculateXPProgress = () => {
    if (!user) return 0;
    const xpNeeded = 100 * user.level;
    let totalXP = 0;
    for (let i = 1; i < user.level; i++) {
      totalXP += 100 * i;
    }
    const currentLevelXP = user.xp - totalXP;
    return (currentLevelXP / xpNeeded) * 100;
  };

  const getRankColorLocal = (rank: string) => getRankColor(rank);

  if (!user) return null;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor={theme.primary}
        />
      }
    >
      <Animated.View style={[styles.animatedContainer, { opacity: fadeAnim }]}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Text style={styles.welcomeText}>WELCOME BACK,</Text>
            <Text style={[styles.username, { color: theme.primary }]}>
              {user.username.toUpperCase()}
            </Text>
          </View>
          <HunterAvatar
            username={user.username}
            rank={user.rank}
            avatarStyle={user.avatar_style}
            size={56}
          />
        </View>

        {/* Stats Card */}
        <View style={styles.statsCard}>
          <LinearGradient
            colors={['#1a1a1a', '#0a0a0a']}
            style={styles.statsGradient}
          >
            {/* Rank and Level */}
            <View style={styles.rankLevelContainer}>
              <View style={styles.rankBadge}>
                <LinearGradient
                  colors={[getRankColor(user.rank), '#000']}
                  style={styles.rankGradient}
                >
                  <Text style={styles.rankText}>{user.rank} RANK</Text>
                </LinearGradient>
              </View>
              <View style={styles.levelContainer}>
                <Text style={styles.levelLabel}>LEVEL</Text>
                <Text style={styles.levelNumber}>{user.level}</Text>
              </View>
            </View>

            {/* XP Progress */}
            <View style={styles.xpContainer}>
              <View style={styles.xpHeader}>
                <Text style={styles.xpLabel}>EXPERIENCE</Text>
                <Text style={styles.xpText}>
                  {user.xp} XP
                </Text>
              </View>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBg}>
                  <LinearGradient
                    colors={[theme.primary, theme.secondary]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[styles.progressBarFill, { width: `${calculateXPProgress()}%` }]}
                  />
                </View>
              </View>
            </View>

            {/* Arc and Streak */}
            <View style={styles.infoRow}>
              <View style={styles.infoItem}>
                <Ionicons name="flame" size={20} color="#ff6b00" />
                <Text style={styles.infoValue}>{user.streak}</Text>
                <Text style={styles.infoLabel}>DAY STREAK</Text>
              </View>
              <View style={styles.divider} />
              <View style={styles.infoItem}>
                <Ionicons name="trophy" size={20} color="#FFD700" />
                <Text style={styles.infoValue}>{user.total_missions_completed}</Text>
                <Text style={styles.infoLabel}>MISSIONS</Text>
              </View>
            </View>

            {/* Current Arc */}
            <View style={styles.arcContainer}>
              <Text style={styles.arcLabel}>CURRENT ARC</Text>
              <Text style={styles.arcText}>{user.current_arc}</Text>
            </View>
          </LinearGradient>
        </View>

        {/* Quote Card */}
        <View style={styles.quoteCard}>
          <Ionicons name="sparkles" size={24} color={theme.primary} style={styles.quoteIcon} />
          <Text style={styles.quoteText}>&ldquo;{quote.quote}&rdquo;</Text>
          <Text style={[styles.quoteAuthor, { color: theme.primary }]}>&mdash; {quote.author}</Text>
        </View>

        {/* Start Mission Button */}
        <TouchableOpacity
          testID="view-missions-button"
          style={styles.startButton}
          activeOpacity={0.85}
          onPress={() => router.push('/(tabs)/missions')}
        >
          <LinearGradient
            colors={[theme.primary, theme.secondary]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.startButtonGradient}
          >
            <Ionicons name="flash" size={24} color="#000" />
            <Text style={styles.startButtonText}>VIEW MISSIONS</Text>
          </LinearGradient>
        </TouchableOpacity>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  content: {
    padding: 20,
    paddingTop: 60,
  },
  animatedContainer: {
    flex: 1,
  },
  header: {
    marginBottom: 24,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerLeft: {
    flex: 1,
  },
  welcomeText: {
    fontSize: 14,
    color: '#666',
    letterSpacing: 2,
    fontWeight: '600',
  },
  username: {
    fontSize: 32,
    color: '#00f0ff',
    fontWeight: '900',
    letterSpacing: 3,
    marginTop: 4,
  },
  statsCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#00f0ff33',
  },
  statsGradient: {
    padding: 20,
  },
  rankLevelContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  rankBadge: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  rankGradient: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  rankText: {
    fontSize: 16,
    fontWeight: '900',
    color: '#fff',
    letterSpacing: 2,
  },
  levelContainer: {
    alignItems: 'center',
  },
  levelLabel: {
    fontSize: 12,
    color: '#666',
    letterSpacing: 2,
  },
  levelNumber: {
    fontSize: 48,
    fontWeight: '900',
    color: '#00f0ff',
    marginTop: -8,
  },
  xpContainer: {
    marginBottom: 24,
  },
  xpHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  xpLabel: {
    fontSize: 12,
    color: '#666',
    letterSpacing: 2,
  },
  xpText: {
    fontSize: 14,
    color: '#00f0ff',
    fontWeight: '700',
  },
  progressBarContainer: {
    height: 8,
  },
  progressBarBg: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: 24,
    paddingVertical: 16,
    backgroundColor: '#00000066',
    borderRadius: 8,
  },
  infoItem: {
    alignItems: 'center',
    flex: 1,
  },
  divider: {
    width: 1,
    height: 40,
    backgroundColor: '#333',
  },
  infoValue: {
    fontSize: 24,
    fontWeight: '900',
    color: '#fff',
    marginTop: 8,
  },
  infoLabel: {
    fontSize: 10,
    color: '#666',
    marginTop: 4,
    letterSpacing: 1,
  },
  arcContainer: {
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#333',
  },
  arcLabel: {
    fontSize: 10,
    color: '#666',
    letterSpacing: 2,
  },
  arcText: {
    fontSize: 18,
    color: '#00f0ff',
    fontWeight: '700',
    marginTop: 4,
  },
  quoteCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#333',
  },
  quoteIcon: {
    marginBottom: 12,
  },
  quoteText: {
    fontSize: 16,
    color: '#fff',
    fontStyle: 'italic',
    lineHeight: 24,
    marginBottom: 12,
  },
  quoteAuthor: {
    fontSize: 14,
    color: '#00f0ff',
    fontWeight: '600',
  },
  startButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 40,
  },
  startButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 18,
    gap: 12,
  },
  startButtonText: {
    fontSize: 18,
    fontWeight: '900',
    color: '#000',
    letterSpacing: 2,
  },
});
