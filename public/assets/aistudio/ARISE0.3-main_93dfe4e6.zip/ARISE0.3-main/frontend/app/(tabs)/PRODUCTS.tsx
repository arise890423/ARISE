import { Product } from './shop';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    title: 'Hunter Headphones',
    description: 'Immersive focus audio gear for deep work sessions.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
    url: 'https://amzn.to/43p7aE0', // 
  },
  {
    id: 2,
    title: 'Cyber Smartwatch',
    description: 'Track your stats in real-time like a true hunter.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
    url: 'https://amzn.to/43p7aE0', // 
  },
  {
    id: 3,
    title: 'Elite Gaming Mouse',
    description: 'Precision control for maximum performance.',
    image: 'https://images.unsplash.com/photo-1517336714739-489689fd1ca8',
    url: 'https://amzn.to/43p7aE0', // 
  },
  {
    id: 4,
    title: 'RGB Mechanical Keyboard',
    description: 'Level up your setup with premium tactile feedback.',
   image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3',
    url: 'https://amzn.to/43p7aE0', // 
  },
  {
    id: 5,
    title: 'Hunter Energy Drink',
    description: 'Boost your stamina and focus for intense missions.',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3',
    url: 'https://amzn.to/43p7aE0', // 
  },
  {
    id: 6,
    title: 'Bodyband Push Up Board',
    description: 'Push Up Board For Chest, Back, Shoulder, Triceps Foldable Push Up Bar Portable Home Gym Equipment For Men & Women - Black.',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
    url: 'https://amzn.to/43p7aE0', // 
  },
];
