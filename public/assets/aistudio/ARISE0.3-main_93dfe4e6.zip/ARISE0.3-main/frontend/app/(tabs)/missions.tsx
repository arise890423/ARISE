import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  AppState,
  Animated,
  Easing,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../src/context/AuthContext';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import { getThemeColor } from '../../src/utils/theme';
import SystemModal, {
  type SystemModalProps,
  type SystemModalRow,
} from '../../src/components/SystemModal';

const BACKEND_URL = 'https://project-arise-1.onrender.com';
const LOCAL_TIMER_KEY = '@project_arise_timer_cache_v2';
const CUSTOM_MISSIONS_KEY = '@project_arise_custom_missions_v1';
const MANDATORY_KEY = '@project_arise_mandatory_v1';
const HIDDEN_KEY = '@project_arise_hidden_v1';
const LOCAL_STREAK_KEY = '@project_arise_local_streak_date_v1';

// ---------------------------------------------------------------------------
// Mandatory mission cinematic backgrounds
// ---------------------------------------------------------------------------
const MISSION_BACKGROUNDS: { [key: string]: any } = {
  pushups:     require('../../assets/missions/idk.jpg'),
  squats:      require('../../assets/missions/idk.jpg'),
  cold_shower: require('../../assets/missions/idk.jpg'),
  hydration:   require('../../assets/missions/idk.jpg'),
  meditation:  require('../../assets/missions/mountain.jpg'),
  stretching:  require('../../assets/missions/mountain.jpg'),
  breathing:   require('../../assets/missions/mountain.jpg'),
  walking:     require('../../assets/missions/mountain.jpg'),
  deep_work:   require('../../assets/missions/study.jpg'),
  reading:     require('../../assets/missions/study.jpg'),
};

const MISSION_BACKGROUND_DEFAULT = require('../../assets/missions/idk.jpg');

const getMissionBackground = (missionType: string) =>
  MISSION_BACKGROUNDS[missionType] || MISSION_BACKGROUND_DEFAULT;

const xpToReachLevel = (L: number) => (100 * L * (L - 1)) / 2;
const deriveLevelFromXp = (totalXp: number): number => {
  if (totalXp <= 0) return 1;
  const L = Math.floor((1 + Math.sqrt(1 + (8 * totalXp) / 100)) / 2);
  return Math.max(1, L);
};

const deriveRankFromLevel = (level: number): string => {
  if (level >= 50) return 'S';
  if (level >= 35) return 'A';
  if (level >= 20) return 'B';
  if (level >= 10) return 'C';
  if (level >= 5)  return 'D';
  return 'E';
};

const isCustomMission = (m: { id: string }) => m.id.startsWith('custom_');
const isMandatoryMission = (m: { id: string }) => m.id.startsWith('mandatory_');

const computeAutoXp = (
  format: 'timed' | 'instant',
  durationSeconds: number,
  reps: number,
): number => {
  if (format === 'timed') {
    const v = Math.max(0, durationSeconds);
    return Math.max(10, Math.min(300, Math.round(8 + Math.sqrt(v) * 2)));
  }
  const r = Math.max(0, reps);
  return Math.max(10, Math.min(250, Math.round(5 + r * 1.2)));
};

const MANDATORY_POOL: {
  title: string;
  description: string;
  mission_type: string;
  category: string;
  format: 'timed' | 'instant';
  duration_seconds?: number;
  exercise_amount?: number;
}[] = [
  { title: '20 Pushups',         description: 'Build raw upper body strength.', mission_type: 'pushups',      category: 'strength',   format: 'instant', exercise_amount: 20 },
  { title: '30 Squats',          description: 'Forge unbreakable legs.',         mission_type: 'squats',       category: 'strength',   format: 'instant', exercise_amount: 30 },
  { title: '10 Min Meditation',  description: 'Sharpen the mind.',               mission_type: 'meditation',   category: 'mental',     format: 'timed',   duration_seconds: 600 },
  { title: '15 Min Walk',        description: 'Move daily, hunter.',             mission_type: 'walking',      category: 'cardio',     format: 'timed',   duration_seconds: 900 },
  { title: '2 Hour Study',       description: 'Knowledge is power.',             mission_type: 'reading',      category: 'discipline', format: 'timed',   duration_seconds: 7200 },
  { title: 'Drink Water',        description: 'Hydrate. Stay sharp.',            mission_type: 'hydration',    category: 'health',     format: 'instant', exercise_amount: 1 },
  { title: '5 Min Stretching',   description: 'Loosen the body.',                mission_type: 'stretching',   category: 'mobility',   format: 'timed',   duration_seconds: 300 },
  { title: '5 Min Breathing',    description: 'Reset your system.',              mission_type: 'breathing',    category: 'mental',     format: 'timed',   duration_seconds: 300 },
  { title: '30 Min Deep Work',   description: 'Single-task. No phone.',          mission_type: 'deep_work',    category: 'discipline', format: 'timed',   duration_seconds: 1800 },
  { title: '1 Min Cold Shower',  description: 'Steel the body and mind.',        mission_type: 'cold_shower',  category: 'discipline', format: 'timed',   duration_seconds: 60 },
  { title: '50 Pushups',         description: 'Push past your limit.',           mission_type: 'pushups',      category: 'strength',   format: 'instant', exercise_amount: 50 },
  { title: '20 Min Reading',     description: 'Feed the mind.',                  mission_type: 'reading',      category: 'discipline', format: 'timed',   duration_seconds: 1200 },
];

const todayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const yesterdayKey = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const pickThreeMandatory = (): Mission[] => {
  const shuffled = [...MANDATORY_POOL].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, 3).map((p, idx) => {
    const dur = p.duration_seconds ?? 0;
    const reps = p.exercise_amount ?? 0;
    const xp = computeAutoXp(p.format, dur, reps);
    return {
      id: `mandatory_${todayKey()}_${idx}`,
      title: p.title,
      description: p.description,
      xp_reward: xp,
      difficulty_level: 2,
      category: p.category,
      completed: false,
      mission_type: p.mission_type,
      format: p.format,
      duration_seconds: dur,
      started_at: null,
      paused_at: null,
      total_paused_seconds: 0,
      status: 'not_started',
      exercise_amount: reps || undefined,
      base_duration_seconds: dur,
      base_exercise_amount: reps || undefined,
      base_xp_reward: xp,
    } as Mission;
  });
};

type MissionStatus =
  | 'not_started'
  | 'running'
  | 'paused'
  | 'completed'
  | 'cancelled';

type Difficulty = 'beginner' | 'intermediate' | 'hardcore' | 'shadow_monarch';

interface Mission {
  id: string;
  title: string;
  description: string;
  xp_reward: number;
  difficulty_level: number;
  category: string;
  completed: boolean;
  mission_type: string;
  format: string;
  duration_seconds: number;
  started_at: string | null;
  paused_at?: string | null;
  total_paused_seconds?: number;
  status?: MissionStatus;
  difficulty?: Difficulty;
  exercise_amount?: number;
  base_duration_seconds?: number;
  base_xp_reward?: number;
  base_exercise_amount?: number;
}

interface LocalTimerCache {
  [missionId: string]: {
    status: MissionStatus;
    started_at: string | null;
    paused_at: string | null;
    total_paused_seconds: number;
    duration_seconds: number;
    difficulty: Difficulty;
    updated_at: number;
  };
}

const TYPE_ICONS: { [key: string]: any } = {
  pushups: 'fitness',
  squats: 'body',
  plank: 'barbell',
  stretching: 'accessibility',
  meditation: 'leaf',
  reading: 'book',
  journaling: 'create',
  breathing: 'pulse',
  cold_shower: 'snow',
  screen_detox: 'phone-portrait',
  deep_work: 'flash',
  running: 'walk',
  walking: 'walk',
};

const CATEGORY_ICONS: { [key: string]: any } = {
  strength: 'barbell',
  cardio: 'walk',
  health: 'water',
  discipline: 'book',
  mental: 'leaf',
  mobility: 'accessibility',
  recovery: 'bed',
};

const CATEGORY_COLORS: { [key: string]: string } = {
  strength: '#ff4d6d',
  cardio: '#499be3',
  health: '#60a5fa',
  discipline: '#fbbf24',
  mental: '#a855f7',
  mobility: '#22d3ee',
  recovery: '#f472b6',
};

const FORCE_TIMED_TYPES = new Set<string>([
  'meditation', 'reading', 'journaling', 'breathing', 'breathing_exercise',
  'deep_work', 'screen_detox', 'stretching', 'walking', 'walking_journey',
  'journey', 'running', 'plank', 'cold_shower',
]);

const TYPE_DEFAULTS: {
  [key: string]: { duration?: number; reps?: number };
} = {
  meditation: { duration: 600 },
  reading: { duration: 900 },
  journaling: { duration: 600 },
  breathing: { duration: 240 },
  breathing_exercise: { duration: 240 },
  deep_work: { duration: 1500 },
  screen_detox: { duration: 1800 },
  stretching: { duration: 300 },
  walking: { duration: 1800 },
  walking_journey: { duration: 1800 },
  journey: { duration: 1800 },
  running: { duration: 1200 },
  plank: { duration: 60 },
  cold_shower: { duration: 120 },
  pushups: { reps: 20 },
  squats: { reps: 25 },
};

const MISSION_LIMITS: {
  [key: string]: {
    duration?: { min: number; max: number };
    reps?: { min: number; max: number };
  };
} = {
  pushups:       { reps:     { min: 5,    max: 500   } },
  squats:        { reps:     { min: 5,    max: 500   } },
  plank:         { duration: { min: 15,   max: 600   } },
  stretching:    { duration: { min: 120,  max: 1800  } },
  meditation:    { duration: { min: 120,  max: 3600  } },
  journaling:    { duration: { min: 120,  max: 3600  } },
  breathing:     { duration: { min: 60,   max: 1800  } },
  breathing_exercise: { duration: { min: 60, max: 1800 } },
  reading:       { duration: { min: 300,  max: 7200  } },
  deep_work:     { duration: { min: 600,  max: 14400 } },
  screen_detox:  { duration: { min: 300,  max: 28800 } },
  cold_shower:   { duration: { min: 30,   max: 600   } },
  walking:       { duration: { min: 300,  max: 10800 } },
  running:       { duration: { min: 300,  max: 7200  } },
  sleep:         { duration: { min: 21600, max: 43200 } },
};

const DEFAULT_LIMITS = {
  duration: { min: 30,  max: 7200 },
  reps:     { min: 1,   max: 500  },
};

const getDurationLimits = (type: string) =>
  MISSION_LIMITS[type]?.duration ?? DEFAULT_LIMITS.duration;
const getRepsLimits = (type: string) =>
  MISSION_LIMITS[type]?.reps ?? DEFAULT_LIMITS.reps;

const getDurationStep = (current: number) => {
  if (current < 60) return 10;
  if (current < 600) return 30;
  if (current < 3600) return 60;
  if (current < 14400) return 300;
  return 1800;
};
const REPS_STEP = 5;

export default function Missions() {
  const { token, user, updateUser } = useAuth();
  const theme = getThemeColor(user?.theme_color);

  const [missions, setMissions] = useState<Mission[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now());
  const [modal, setModal] = useState<Omit<SystemModalProps, 'visible'> | null>(null);
  const [customMissions, setCustomMissions] = useState<Mission[]>([]);
  const [mandatoryMissions, setMandatoryMissions] = useState<Mission[]>([]);
  const [hiddenIds, setHiddenIds] = useState<string[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [draft, setDraft] = useState({
    title: '',
    description: '',
    format: 'timed' as 'timed' | 'instant',
    duration_seconds: 600,
    exercise_amount: 10,
  });

  const closeModal = useCallback(() => setModal(null), []);
  const showModal = useCallback(
    (config: Omit<SystemModalProps, 'visible'>) => setModal(config),
    [],
  );

  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pulseAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (token) {
      loadCustomMissions();
      loadMandatoryMissions();
      loadHidden();
      hydrateFromCache().then(() => loadMissions());
    }
  }, [token]);

  useEffect(() => {
    const allLive = [...missions, ...customMissions, ...mandatoryMissions];
    const hasRunningTimer = allLive.some(
      (m) => deriveStatus(m) === 'running' && !m.completed,
    );
    if (hasRunningTimer && !tickRef.current) {
      tickRef.current = setInterval(() => setNow(Date.now()), 1000);
    } else if (!hasRunningTimer && tickRef.current) {
      clearInterval(tickRef.current);
      tickRef.current = null;
    }
    return () => {
      if (tickRef.current) {
        clearInterval(tickRef.current);
        tickRef.current = null;
      }
    };
  }, [missions, customMissions, mandatoryMissions]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') {
        setNow(Date.now());
        if (token) loadMissions();
      }
    });
    return () => sub.remove();
  }, [token]);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1, duration: 1400, easing: Easing.inOut(Easing.ease), useNativeDriver: false }),
        Animated.timing(pulseAnim, { toValue: 0, duration: 1400, easing: Easing.inOut(Easing.ease), useNativeDriver: false }),
      ]),
    ).start();
  }, [pulseAnim]);

  const readCache = useCallback(async (): Promise<LocalTimerCache> => {
    try {
      const raw = await AsyncStorage.getItem(LOCAL_TIMER_KEY);
      return raw ? (JSON.parse(raw) as LocalTimerCache) : {};
    } catch { return {}; }
  }, []);

  const writeCache = useCallback(async (mission: Mission) => {
    try {
      const cache = await readCache();
      cache[mission.id] = {
        status: deriveStatus(mission),
        started_at: mission.started_at,
        paused_at: mission.paused_at ?? null,
        total_paused_seconds: mission.total_paused_seconds ?? 0,
        duration_seconds: mission.duration_seconds,
        difficulty: mission.difficulty ?? 'intermediate',
        updated_at: Date.now(),
      };
      await AsyncStorage.setItem(LOCAL_TIMER_KEY, JSON.stringify(cache));
    } catch {}
  }, [readCache]);

  const clearCacheEntry = useCallback(async (missionId: string) => {
    try {
      const cache = await readCache();
      delete cache[missionId];
      await AsyncStorage.setItem(LOCAL_TIMER_KEY, JSON.stringify(cache));
    } catch {}
  }, [readCache]);

  const hydrateFromCache = useCallback(async () => {
    const cache = await readCache();
    if (Object.keys(cache).length === 0) return;
    setMissions((prev) =>
      prev.map((m) => {
        const c = cache[m.id];
        if (!c) return m;
        return normalizeMission({
          ...m,
          started_at: c.started_at,
          paused_at: c.paused_at,
          total_paused_seconds: c.total_paused_seconds,
          duration_seconds: c.duration_seconds,
          status: c.status,
          difficulty: c.difficulty,
        });
      }),
    );
  }, [readCache]);

  const apiFetch = useCallback(
    async (path: string, body?: any, method: string = 'POST') => {
      const mid = body && (body.mission_id as string | undefined);
      if (mid && (mid.startsWith('custom_') || mid.startsWith('mandatory_'))) {
        return { ok: true, data: {}, status: 200 };
      }
      const response = await fetch(`${BACKEND_URL}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: body ? JSON.stringify(body) : undefined,
      });
      const ok = response.ok;
      let data: any = null;
      try { data = await response.json(); } catch {}
      return { ok, data, status: response.status };
    },
    [token],
  );

  const normalizeMission = (m: Mission): Mission => {
    const forceTimed = FORCE_TIMED_TYPES.has(m.mission_type);
    const defaults = TYPE_DEFAULTS[m.mission_type] || {};
    const format = forceTimed ? 'timed' : m.format;

    if (forceTimed && (!m.duration_seconds || m.duration_seconds <= 0)) {
      m.duration_seconds = defaults.duration ?? 300;
    }

    const baseDuration =
      m.base_duration_seconds ??
      (m.duration_seconds && m.duration_seconds > 0 ? m.duration_seconds : defaults.duration);
    const baseReps =
      m.base_exercise_amount ??
      (m.exercise_amount && m.exercise_amount > 0 ? m.exercise_amount : defaults.reps);
    const baseXp = m.base_xp_reward ?? m.xp_reward;

    return {
      ...m,
      format,
      base_duration_seconds: baseDuration,
      base_exercise_amount: baseReps,
      base_xp_reward: baseXp,
      duration_seconds:
        format === 'timed' && (!m.duration_seconds || m.duration_seconds <= 0)
          ? baseDuration ?? 300
          : m.duration_seconds,
      exercise_amount: m.exercise_amount ?? baseReps,
      total_paused_seconds: m.total_paused_seconds ?? 0,
    };
  };

  const loadCustomMissions = useCallback(async () => {
    try {
      const raw = await AsyncStorage.getItem(CUSTOM_MISSIONS_KEY);
      const list: Mission[] = raw ? JSON.parse(raw) : [];
      setCustomMissions(list.map((m) => normalizeMission(m)));
    } catch { setCustomMissions([]); }
  }, []);

  const persistCustomMissions = useCallback(async (list: Mission[]) => {
    try { await AsyncStorage.setItem(CUSTOM_MISSIONS_KEY, JSON.stringify(list)); } catch {}
  }, []);

  const createCustomMission = async () => {
    if (!draft.title.trim()) { showError('Please give the quest a name.'); return; }
    const id = `custom_${Date.now()}`;
    const baseDuration = draft.format === 'timed' ? Math.max(10, Math.min(43200, Math.round(draft.duration_seconds))) : 0;
    const baseReps = draft.format === 'instant' ? Math.max(1, Math.min(500, Math.round(draft.exercise_amount))) : 0;
    const xp = computeAutoXp(draft.format, baseDuration, baseReps);
    const newMission: Mission = normalizeMission({
      id, title: draft.title.trim(),
      description: draft.description.trim() || 'Custom quest',
      xp_reward: xp, difficulty_level: 1, category: 'discipline',
      completed: false, mission_type: 'custom', format: draft.format,
      duration_seconds: baseDuration, started_at: null, paused_at: null,
      total_paused_seconds: 0, status: 'not_started',
      exercise_amount: baseReps || undefined,
      base_duration_seconds: baseDuration,
      base_exercise_amount: baseReps || undefined,
      base_xp_reward: xp,
    });
    const next = [newMission, ...customMissions];
    setCustomMissions(next);
    await persistCustomMissions(next);
    setShowCreate(false);
    setDraft({ title: '', description: '', format: 'timed', duration_seconds: 600, exercise_amount: 10 });
  };

  const patchCustom = (id: string, patch: Partial<Mission>) => {
    setCustomMissions((prev) => {
      const next = prev.map((m) => (m.id === id ? { ...m, ...patch } : m));
      persistCustomMissions(next);
      return next;
    });
  };

  const deleteCustomMission = async (id: string) => {
    const next = customMissions.filter((m) => m.id !== id);
    setCustomMissions(next);
    await persistCustomMissions(next);
  };

  const loadMissions = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/missions/daily`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        const data: Mission[] = await response.json();
        const cache = await readCache();
        const merged = data.map((raw) => {
          const m = normalizeMission(raw);
          const c = cache[m.id];
          const hasBackendState = m.status !== undefined || m.started_at !== null || m.paused_at !== undefined;
          if (!hasBackendState && c) {
            return normalizeMission({
              ...m,
              started_at: c.started_at, paused_at: c.paused_at,
              total_paused_seconds: c.total_paused_seconds,
              duration_seconds: c.duration_seconds,
              status: c.status, difficulty: c.difficulty,
            });
          }
          if (c && c.duration_seconds && c.duration_seconds !== m.duration_seconds) {
            return normalizeMission({
              ...m,
              duration_seconds: c.duration_seconds,
              base_duration_seconds: c.duration_seconds,
              difficulty: m.difficulty ?? c.difficulty ?? 'intermediate',
            });
          }
          return { ...m, difficulty: m.difficulty ?? c?.difficulty ?? 'intermediate' };
        });
        setMissions(merged);
        merged.forEach((m) => writeCache(m));
      }
    } catch (error) {
      console.error('Error loading missions:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadMissions();
    setRefreshing(false);
  };

  function deriveStatus(m: Mission): MissionStatus {
    if (m.completed) return 'completed';
    if (m.status) return m.status;
    if (!m.started_at) return 'not_started';
    if (m.paused_at) return 'paused';
    return 'running';
  }

  const getRemainingSeconds = (mission: Mission): number => {
    const status = deriveStatus(mission);
    const duration = mission.duration_seconds || 0;
    const totalPaused = mission.total_paused_seconds ?? 0;
    if (status === 'not_started' || status === 'cancelled') return duration;
    if (!mission.started_at) return duration;
    const startMs = new Date(mission.started_at).getTime();
    if (status === 'paused' && mission.paused_at) {
      const pausedAt = new Date(mission.paused_at).getTime();
      const elapsed = Math.floor((pausedAt - startMs) / 1000) - totalPaused;
      return Math.max(0, duration - Math.max(0, elapsed));
    }
    const elapsed = Math.floor((now - startMs) / 1000) - totalPaused;
    return Math.max(0, duration - Math.max(0, elapsed));
  };

  const getTimerProgress = (mission: Mission): number => {
    const duration = mission.duration_seconds || 1;
    const remaining = getRemainingSeconds(mission);
    const elapsed = duration - remaining;
    return Math.max(0, Math.min(100, (elapsed / duration) * 100));
  };

  const patchMission = (id: string, patch: Partial<Mission>) => {
    if (id.startsWith('custom_')) { patchCustom(id, patch); return; }
    if (id.startsWith('mandatory_')) { patchMandatory(id, patch); return; }
    setMissions((prev) => {
      const next = prev.map((m) => (m.id === id ? { ...m, ...patch } : m));
      const updated = next.find((m) => m.id === id);
      if (updated) writeCache(updated);
      return next;
    });
  };

  const persistMandatory = useCallback(async (list: Mission[]) => {
    try { await AsyncStorage.setItem(MANDATORY_KEY, JSON.stringify({ date: todayKey(), list })); } catch {}
  }, []);

  const loadMandatoryMissions = useCallback(async () => {
    try {
      const raw = await AsyncStorage.getItem(MANDATORY_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { date: string; list: Mission[] };
        if (parsed.date === todayKey() && Array.isArray(parsed.list)) {
          setMandatoryMissions(parsed.list.map((m) => normalizeMission(m)));
          return;
        }
      }
      const fresh = pickThreeMandatory().map((m) => normalizeMission(m));
      setMandatoryMissions(fresh);
      await AsyncStorage.setItem(MANDATORY_KEY, JSON.stringify({ date: todayKey(), list: fresh }));
    } catch { setMandatoryMissions([]); }
  }, []);

  const patchMandatory = (id: string, patch: Partial<Mission>) => {
    setMandatoryMissions((prev) => {
      const next = prev.map((m) => (m.id === id ? { ...m, ...patch } : m));
      persistMandatory(next);
      return next;
    });
  };

  const persistHidden = useCallback(async (ids: string[]) => {
    try { await AsyncStorage.setItem(HIDDEN_KEY, JSON.stringify(ids)); } catch {}
  }, []);

  const loadHidden = useCallback(async () => {
    try {
      const raw = await AsyncStorage.getItem(HIDDEN_KEY);
      setHiddenIds(raw ? (JSON.parse(raw) as string[]) : []);
    } catch { setHiddenIds([]); }
  }, []);

  const hideMission = async (id: string) => {
    const next = [...hiddenIds, id];
    setHiddenIds(next);
    await persistHidden(next);
  };

  const showError = useCallback((message: string) => {
    showModal({
      title: 'SYSTEM ERROR', message, tone: 'warning',
      actions: [{ label: 'CLOSE', onPress: closeModal, tone: 'secondary' }],
      onDismiss: closeModal,
    });
  }, [showModal, closeModal]);

  const startMissionNow = async (mission: Mission) => {
    setBusyId(mission.id);
    const optimisticStartedAt = new Date().toISOString();
    patchMission(mission.id, {
      started_at: optimisticStartedAt, paused_at: null,
      total_paused_seconds: 0, status: 'running',
    });
    try {
      const { ok, data } = await apiFetch('/api/missions/start', {
        mission_id: mission.id,
        difficulty: mission.difficulty ?? 'intermediate',
        duration_seconds: mission.duration_seconds,
        exercise_amount: mission.exercise_amount,
      });
      if (ok && data) {
        patchMission(mission.id, {
          started_at: data.started_at ?? optimisticStartedAt,
          paused_at: null, total_paused_seconds: 0, status: 'running',
        });
      } else if (data?.detail) {
        console.warn('[missions] start rejected by backend:', data.detail);
      }
    } catch (e) {
      console.warn('[missions] start network error, keeping local timer');
    } finally {
      setBusyId(null);
    }
  };

  const handleStart = (mission: Mission) => {
    const isTimed = mission.format === 'timed' || FORCE_TIMED_TYPES.has(mission.mission_type);
    const rows: SystemModalRow[] = [{ label: 'Quest', value: mission.title, tone: 'highlight' }];
    if (isTimed) rows.push({ label: 'Duration', value: formatDurationLabel(mission.duration_seconds || 0) });
    if (mission.exercise_amount) rows.push({ label: 'Reps', value: `x${mission.exercise_amount}` });
    rows.push({ label: 'Reward', value: `+${mission.xp_reward} XP`, tone: 'highlight' });

    showModal({
      title: 'SYSTEM NOTIFICATION',
      message: 'Will you accept this quest?',
      rows, tone: 'info',
      actions: [
        { label: 'ACCEPT', tone: 'primary', testID: `mission-accept-${mission.mission_type}`,
          onPress: () => { closeModal(); startMissionNow(mission); } },
        { label: 'DECLINE', tone: 'secondary', testID: `mission-decline-${mission.mission_type}`, onPress: closeModal },
      ],
      onDismiss: closeModal,
    });
  };

  const handlePause = async (mission: Mission) => {
    setBusyId(mission.id);
    const pausedAtIso = new Date().toISOString();
    patchMission(mission.id, { status: 'paused', paused_at: pausedAtIso });
    try {
      const { ok, data } = await apiFetch('/api/missions/pause', { mission_id: mission.id });
      if (ok && data?.paused_at) {
        patchMission(mission.id, {
          paused_at: data.paused_at,
          total_paused_seconds: data.total_paused_seconds ?? mission.total_paused_seconds ?? 0,
          status: 'paused',
        });
      }
    } catch {} finally { setBusyId(null); }
  };

  const handleResume = async (mission: Mission) => {
    setBusyId(mission.id);
    const pausedAtMs = mission.paused_at ? new Date(mission.paused_at).getTime() : Date.now();
    const pausedDelta = Math.max(0, Math.floor((Date.now() - pausedAtMs) / 1000));
    const newTotalPaused = (mission.total_paused_seconds ?? 0) + pausedDelta;
    patchMission(mission.id, { status: 'running', paused_at: null, total_paused_seconds: newTotalPaused });
    try {
      const { ok, data } = await apiFetch('/api/missions/resume', { mission_id: mission.id });
      if (ok && data) {
        patchMission(mission.id, {
          paused_at: null, total_paused_seconds: data.total_paused_seconds ?? newTotalPaused, status: 'running',
        });
      }
    } catch {} finally { setBusyId(null); }
  };

  const handleCancel = (mission: Mission) => {
    showModal({
      title: 'SYSTEM WARNING',
      message: 'This quest progress will be lost.',
      rows: [{ label: 'Quest', value: mission.title, tone: 'highlight' }],
      tone: 'warning',
      actions: [
        { label: 'ABANDON QUEST', tone: 'danger', testID: `mission-abandon-${mission.mission_type}`,
          onPress: async () => {
            closeModal();
            setBusyId(mission.id);
            patchMission(mission.id, { status: 'cancelled', started_at: null, paused_at: null, total_paused_seconds: 0 });
            try { await apiFetch('/api/missions/cancel', { mission_id: mission.id }); } catch {}
            finally { await clearCacheEntry(mission.id); setBusyId(null); }
          } },
        { label: 'CONTINUE MISSION', tone: 'primary', testID: `mission-continue-${mission.mission_type}`, onPress: closeModal },
      ],
      onDismiss: closeModal,
    });
  };

  const handleReset = (mission: Mission) => {
    showModal({
      title: 'SYSTEM NOTIFICATION',
      message: 'Reset this quest? The timer will return to its full duration.',
      rows: [{ label: 'Quest', value: mission.title, tone: 'highlight' }],
      tone: 'info',
      actions: [
        { label: 'RESET', tone: 'danger', testID: `mission-reset-confirm-${mission.mission_type}`,
          onPress: async () => {
            closeModal();
            setBusyId(mission.id);
            patchMission(mission.id, { status: 'not_started', started_at: null, paused_at: null, total_paused_seconds: 0 });
            try { await apiFetch('/api/missions/reset', { mission_id: mission.id }); } catch {}
            finally { await clearCacheEntry(mission.id); setBusyId(null); }
          } },
        { label: 'KEEP', tone: 'secondary', testID: `mission-reset-keep-${mission.mission_type}`, onPress: closeModal },
      ],
      onDismiss: closeModal,
    });
  };

  const completeMission = async (mission: Mission) => {
    const isForcedTimed = mission.format === 'timed' || FORCE_TIMED_TYPES.has(mission.mission_type);
    if (isForcedTimed && mission.started_at) {
      const remainingLocal = getRemainingSeconds(mission);
      if (remainingLocal > 0) {
        showError(`Timer still running. ${formatDurationLabel(remainingLocal)} remaining.`);
        return;
      }
    }

    setBusyId(mission.id);
    try {
      const { ok, data } = await apiFetch('/api/missions/complete', { mission_id: mission.id });
      const isCustom = isCustomMission(mission);
      const isMandatory = isMandatoryMission(mission);
      const isLocalOnly = isCustom || isMandatory;
      if (ok) {
        patchMission(mission.id, { completed: true, status: 'completed' });
        await clearCacheEntry(mission.id);

        const xpGained = isLocalOnly ? mission.xp_reward : data.xp_gained ?? mission.xp_reward;

        let newStreak: number = user?.streak ?? 0;
        if (isLocalOnly) {
          try {
            const lastDay = await AsyncStorage.getItem(LOCAL_STREAK_KEY);
            const today = todayKey();
            if (lastDay !== today) {
              newStreak = lastDay === yesterdayKey() ? (user?.streak ?? 0) + 1 : 1;
              await AsyncStorage.setItem(LOCAL_STREAK_KEY, today);
            }
          } catch {}
        } else {
          newStreak = data.new_streak ?? 0;
        }

        const leveledUp = !isLocalOnly && data.leveled_up;

        const rows: SystemModalRow[] = [
          { label: 'XP Gained', value: `+${xpGained}`, tone: 'highlight' },
          { label: 'Streak', value: `${newStreak} days` },
        ];
        if (leveledUp) {
          rows.push({ label: 'Level', value: `${data.new_level} · ${data.new_rank}`, tone: 'highlight' });
        }

        showModal({
          title: leveledUp ? 'LEVEL UP' : 'QUEST COMPLETED',
          message: leveledUp
            ? `You have reached Level ${data.new_level}.\nNew rank acquired.`
            : 'Congratulations Hunter.\nMission completed successfully.',
          rows, tone: 'success',
          actions: [
            { label: 'CLAIM REWARD', tone: 'primary', testID: `mission-claim-confirm-${mission.mission_type}`, onPress: closeModal },
            { label: 'CLOSE', tone: 'secondary', onPress: closeModal },
          ],
          onDismiss: closeModal,
        });

        if (isLocalOnly) {
          if (user) {
            const newXp = (user.xp ?? 0) + xpGained;
            const newLevel = deriveLevelFromXp(newXp);
            const newRank = deriveRankFromLevel(newLevel);
            const newTotal = (user.total_missions_completed ?? 0) + 1;

            await updateUser({
              ...user, xp: newXp, level: newLevel, rank: newRank,
              streak: newStreak, total_missions_completed: newTotal,
            });

            try {
              const persistResp = await fetch(`${BACKEND_URL}/api/user/sync-progress`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
                body: JSON.stringify({ xp: newXp, level: newLevel, rank: newRank, streak: newStreak, total_missions_completed: newTotal }),
              });
              if (persistResp.ok) {
                console.log('[missions] local-only XP persisted →', 'xp=', newXp, 'level=', newLevel);
              } else {
                console.warn('[missions] sync-progress rejected:', persistResp.status);
              }
            } catch (e) {
              console.warn('[missions] sync-progress network error:', e);
            }
          }
        } else {
          try {
            const meResp = await fetch(`${BACKEND_URL}/api/auth/me`, { headers: { Authorization: `Bearer ${token}` } });
            if (meResp.ok) {
              const freshUser = await meResp.json();
              const localXp: number = user?.xp ?? 0;
              const localLevel: number = user?.level ?? 1;
              const backendXp: number = typeof freshUser?.xp === 'number' ? freshUser.xp : 0;
              const backendLevel: number = typeof freshUser?.level === 'number' ? freshUser.level : 1;
              const accept = backendLevel > localLevel || backendXp >= localXp;
              if (accept) {
                await updateUser(freshUser);
              } else if (user) {
                await updateUser({
                  ...user,
                  xp: data.new_xp ?? user.xp, level: data.new_level ?? user.level,
                  rank: data.new_rank ?? user.rank, current_arc: data.new_arc ?? user.current_arc,
                  streak: newStreak,
                  total_missions_completed: (user.total_missions_completed ?? 0) + 1,
                });
              }
            } else if (user) {
              await updateUser({
                ...user,
                xp: data.new_xp ?? user.xp, level: data.new_level ?? user.level,
                rank: data.new_rank ?? user.rank, current_arc: data.new_arc ?? user.current_arc,
                streak: newStreak,
                total_missions_completed: (user.total_missions_completed ?? 0) + 1,
              });
            }
          } catch {
            if (user) {
              await updateUser({
                ...user,
                xp: data.new_xp ?? user.xp, level: data.new_level ?? user.level,
                rank: data.new_rank ?? user.rank, current_arc: data.new_arc ?? user.current_arc,
                streak: newStreak,
                total_missions_completed: (user.total_missions_completed ?? 0) + 1,
              });
            }
          }
        }
      } else {
        const detail = data?.detail || 'Failed to complete mission.';
        showError(detail);
      }
    } catch {
      showError('Failed to connect to server.');
    } finally {
      setBusyId(null);
    }
  };

  const handleCompleteInstant = (mission: Mission) => {
    const rows: SystemModalRow[] = [{ label: 'Quest', value: mission.title, tone: 'highlight' }];
    if (mission.exercise_amount) rows.push({ label: 'Target', value: `x${mission.exercise_amount}` });
    rows.push({ label: 'Reward', value: `+${mission.xp_reward} XP`, tone: 'highlight' });
    showModal({
      title: 'SYSTEM NOTIFICATION', message: 'Will you accept this quest?',
      rows, tone: 'info',
      actions: [
        { label: 'ACCEPT', tone: 'primary', testID: `mission-accept-${mission.mission_type}`,
          onPress: () => { closeModal(); completeMission(mission); } },
        { label: 'DECLINE', tone: 'secondary', onPress: closeModal },
      ],
      onDismiss: closeModal,
    });
  };

  const handleClaimReward = (mission: Mission) => {
    showModal({
      title: 'QUEST READY', message: 'Timer complete.\nClaim your reward, Hunter.',
      rows: [
        { label: 'Quest', value: mission.title, tone: 'highlight' },
        { label: 'Reward', value: `+${mission.xp_reward} XP`, tone: 'highlight' },
      ],
      tone: 'success',
      actions: [
        { label: 'CLAIM REWARD', tone: 'primary', testID: `mission-claim-confirm-${mission.mission_type}`,
          onPress: () => { closeModal(); completeMission(mission); } },
        { label: 'CLOSE', tone: 'secondary', onPress: closeModal },
      ],
      onDismiss: closeModal,
    });
  };

  const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

  const handleAdjustDuration = async (mission: Mission, delta: 1 | -1) => {
    const current = mission.duration_seconds ?? 0;
    const limits = getDurationLimits(mission.mission_type);
    const step = getDurationStep(current);
    const next = clamp(current + delta * step, limits.min, limits.max);
    if (next === current) return;
    patchMission(mission.id, { duration_seconds: next, base_duration_seconds: next });
    try { await apiFetch('/api/missions/customize', { mission_id: mission.id, duration_seconds: next }); } catch {}
  };

  const handleAdjustReps = async (mission: Mission, delta: 1 | -1) => {
    const current = mission.exercise_amount ?? 0;
    const limits = getRepsLimits(mission.mission_type);
    const next = clamp(current + delta * REPS_STEP, limits.min, limits.max);
    if (next === current) return;
    patchMission(mission.id, { exercise_amount: next, base_exercise_amount: next });
    try { await apiFetch('/api/missions/customize', { mission_id: mission.id, exercise_amount: next }); } catch {}
  };

  const getCategoryIcon = (mission: Mission): any =>
    TYPE_ICONS[mission.mission_type] || CATEGORY_ICONS[mission.category] || 'star';

  const getCategoryColor = (mission: Mission): string =>
    CATEGORY_COLORS[mission.category] || theme.primary;

  const formatDurationLabel = (s: number) => {
    if (s <= 0) return '0s';
    if (s < 60) return `${s}s`;
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0 && m > 0) return `${h}h ${m}m`;
    if (h > 0) return `${h}h`;
    if (sec > 0 && m < 5) return `${m}m ${sec}s`;
    return `${m}m`;
  };

  const formatCountdown = (s: number) => {
    const v = Math.max(0, Math.floor(s));
    const h = Math.floor(v / 3600);
    const m = Math.floor((v % 3600) / 60);
    const sec = v % 60;
    const pad = (n: number) => String(n).padStart(2, '0');
    if (h > 0) return `${h}:${pad(m)}:${pad(sec)}`;
    return `${m}:${pad(sec)}`;
  };

  const renderCustomizer = (mission: Mission) => {
    const isTimed = mission.format === 'timed';
    const hasReps = (mission.exercise_amount ?? 0) > 0 || !isTimed;
    return (
      <View style={styles.customizeWrap}>
        {isTimed && (
          <View style={styles.stepperRow}>
            <Text style={styles.stepperLabel}>DURATION</Text>
            <View style={styles.stepperGroup}>
              <TouchableOpacity testID={`mission-duration-minus-${mission.mission_type}`}
                onPress={() => handleAdjustDuration(mission, -1)} style={styles.stepperBtn} activeOpacity={0.7}>
                <Ionicons name="remove" size={16} color="#fff" />
              </TouchableOpacity>
              <Text style={styles.stepperValue}>{formatDurationLabel(mission.duration_seconds || 0)}</Text>
              <TouchableOpacity testID={`mission-duration-plus-${mission.mission_type}`}
                onPress={() => handleAdjustDuration(mission, 1)} style={styles.stepperBtn} activeOpacity={0.7}>
                <Ionicons name="add" size={16} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        )}
        {hasReps && (mission.exercise_amount ?? 0) > 0 && (
          <View style={styles.stepperRow}>
            <Text style={styles.stepperLabel}>REPS</Text>
            <View style={styles.stepperGroup}>
              <TouchableOpacity testID={`mission-reps-minus-${mission.mission_type}`}
                onPress={() => handleAdjustReps(mission, -1)} style={styles.stepperBtn} activeOpacity={0.7}>
                <Ionicons name="remove" size={16} color="#fff" />
              </TouchableOpacity>
              <Text style={styles.stepperValue}>x{mission.exercise_amount}</Text>
              <TouchableOpacity testID={`mission-reps-plus-${mission.mission_type}`}
                onPress={() => handleAdjustReps(mission, 1)} style={styles.stepperBtn} activeOpacity={0.7}>
                <Ionicons name="add" size={16} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    );
  };

  const renderTimerControls = (mission: Mission, status: MissionStatus, isTimerDone: boolean) => {
    if (isTimerDone) {
      return (
        <TouchableOpacity testID={`mission-claim-${mission.mission_type}`} style={styles.actionButton}
          onPress={() => handleClaimReward(mission)} disabled={busyId === mission.id} activeOpacity={0.85}>
          <LinearGradient colors={['#10b981', '#059669']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.actionGradient}>
            {busyId === mission.id ? <ActivityIndicator color="#000" /> : (
              <><Ionicons name="trophy" size={18} color="#000" /><Text style={styles.actionText}>CLAIM REWARD</Text></>
            )}
          </LinearGradient>
        </TouchableOpacity>
      );
    }
    if (status === 'running') {
      return (
        <View style={styles.controlsRow}>
          <ControlButton testID={`mission-pause-${mission.mission_type}`} icon="pause" label="PAUSE" color="#fbbf24"
            onPress={() => handlePause(mission)} busy={busyId === mission.id} flex={2} />
          <ControlButton testID={`mission-reset-${mission.mission_type}`} icon="refresh" label="RESET" color="#60a5fa"
            onPress={() => handleReset(mission)} busy={busyId === mission.id} flex={1} outlined />
          <ControlButton testID={`mission-cancel-${mission.mission_type}`} icon="close" label="CANCEL" color="#ef4444"
            onPress={() => handleCancel(mission)} busy={busyId === mission.id} flex={1} outlined />
        </View>
      );
    }
    if (status === 'paused') {
      return (
        <View style={styles.controlsRow}>
          <ControlButton testID={`mission-resume-${mission.mission_type}`} icon="play" label="RESUME" color="#10b981"
            onPress={() => handleResume(mission)} busy={busyId === mission.id} flex={2} />
          <ControlButton testID={`mission-reset-${mission.mission_type}`} icon="refresh" label="RESET" color="#60a5fa"
            onPress={() => handleReset(mission)} busy={busyId === mission.id} flex={1} outlined />
          <ControlButton testID={`mission-cancel-${mission.mission_type}`} icon="close" label="CANCEL" color="#ef4444"
            onPress={() => handleCancel(mission)} busy={busyId === mission.id} flex={1} outlined />
        </View>
      );
    }
    return (
      <TouchableOpacity testID={`mission-start-${mission.mission_type}`} style={styles.actionButton}
        onPress={() => handleStart(mission)} disabled={busyId === mission.id} activeOpacity={0.85}>
        <LinearGradient colors={[theme.primary, theme.secondary]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.actionGradient}>
          {busyId === mission.id ? <ActivityIndicator color="#000" /> : (
            <><Ionicons name="play" size={18} color="#000" /><Text style={styles.actionText}>START MISSION</Text></>
          )}
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  const handleDeleteRequest = (mission: Mission) => {
    const custom = isCustomMission(mission);
    const mandatory = isMandatoryMission(mission);
    if (mandatory) {
      showModal({
        title: 'SYSTEM LOCKED', message: 'Mandatory daily quests cannot be abandoned.',
        tone: 'warning',
        actions: [{ label: 'UNDERSTOOD', tone: 'secondary', onPress: closeModal }],
        onDismiss: closeModal,
      });
      return;
    }
    showModal({
      title: 'ABANDON QUEST',
      message: custom ? 'Abandon this custom quest? It will be permanently deleted.' : 'Abandon this quest? It will be hidden from your list.',
      rows: [{ label: 'Quest', value: mission.title, tone: 'highlight' }],
      tone: 'warning',
      actions: [
        { label: custom ? 'DELETE QUEST' : 'DISMISS QUEST', tone: 'danger', testID: `mission-delete-confirm-${mission.id}`,
          onPress: async () => {
            closeModal();
            await clearCacheEntry(mission.id);
            if (custom) await deleteCustomMission(mission.id);
            else await hideMission(mission.id);
          } },
        { label: 'KEEP QUEST', tone: 'primary', testID: `mission-delete-keep-${mission.id}`, onPress: closeModal },
      ],
      onDismiss: closeModal,
    });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  const allMissions = [
    ...mandatoryMissions,
    ...customMissions,
    ...missions.filter((m) => !hiddenIds.includes(m.id)),
  ];
  const completedCount = allMissions.filter((m) => m.completed).length;
  const glowOpacity = pulseAnim.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.85] });

  return (
    <>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}>
        <View style={styles.header}>
          <View>
            <Text style={styles.subtitle}>YOUR DAILY</Text>
            <Text style={[styles.title, { color: theme.primary }]}>MISSIONS</Text>
          </View>
          <View style={[styles.progressBadge, { borderColor: theme.primary + '55' }]}>
            <Text style={styles.progressText}>{completedCount}/{allMissions.length}</Text>
            <Ionicons name="checkmark-done" size={18} color={theme.primary} />
          </View>
        </View>

        <View style={styles.missionsContainer}>
          {allMissions.map((mission, idx) => {
            const prev = idx > 0 ? allMissions[idx - 1] : null;
            const mandatory = isMandatoryMission(mission);
            const showMandatoryHeader = idx === 0 && mandatory;
            const showRegularHeader = !!prev && isMandatoryMission(prev) && !mandatory;
            const isTimed = mission.format === 'timed' || FORCE_TIMED_TYPES.has(mission.mission_type);
            const status = deriveStatus(mission);
            const isActive = status === 'running' || status === 'paused';
            const remaining = isTimed ? getRemainingSeconds(mission) : 0;
            const isTimerDone = isTimed && !!mission.started_at && (status === 'running' || status === 'paused') && remaining <= 0;
            const progress = isTimed ? getTimerProgress(mission) : 0;
            const categoryColor = mandatory ? '#ff4d6d' : getCategoryColor(mission);
            const borderColor = mandatory ? '#ff4d6d'
              : status === 'completed' ? '#10b98155'
              : status === 'paused' ? '#fbbf24'
              : status === 'running' ? theme.primary
              : status === 'cancelled' ? '#ef444466'
              : '#222';
            const canDelete = !mandatory;
            const accentGlow = mandatory ? '#ff4d6d' : status === 'paused' ? '#fbbf24' : theme.primary;

            return (
              <React.Fragment key={mission.id}>
                {showMandatoryHeader && (
                  <SectionHeader label="DAILY MANDATORY QUESTS" caption="System-assigned hunter tasks" color="#ff4d6d" />
                )}
                {showRegularHeader && (
                  <SectionHeader label="YOUR QUESTS" caption="Custom and optional" color={theme.primary} />
                )}
                <View
                  style={[styles.missionCard, { borderColor, borderWidth: mandatory ? 1.8 : 1.5 }]}
                  testID={`mission-card-${mission.mission_type}`}
                >
                  {mandatory && (
                    <>
                      <View pointerEvents="none" style={styles.mandatoryBg}>
                        <Image
                          source={getMissionBackground(mission.mission_type)}
                          style={styles.mandatoryBgImage}
                          resizeMode="cover"
                        />
                      </View>
                      <View pointerEvents="none" style={styles.mandatoryScrim} />
                    </>
                  )}
                  {(isActive || mandatory) && (
                    <Animated.View
                      pointerEvents="none"
                      style={[styles.glow, {
                        opacity: mandatory ? 0.55 : glowOpacity,
                        shadowColor: accentGlow,
                        borderColor: accentGlow,
                      }]}
                    />
                  )}
                  <LinearGradient
                    colors={
                      mandatory
                        ? ['rgba(28,7,9,0.55)', 'rgba(10,2,4,0.92)']
                        : status === 'completed'
                        ? ['#0b1f12', '#050b07']
                        : status === 'paused'
                        ? ['#1c1608', '#0a0a12']
                        : ['#15151c', '#0a0a12']
                    }
                    style={styles.missionGradient}
                  >
                    <View style={styles.missionHeader}>
                      <View style={[styles.categoryBadge, { backgroundColor: categoryColor + '22' }]}>
                        <Ionicons name={mandatory ? 'alert-circle' : getCategoryIcon(mission)} size={14} color={categoryColor} />
                        <Text style={[styles.categoryText, { color: categoryColor }]}>
                          {mandatory ? 'MANDATORY' : (mission.mission_type || mission.category).replace(/_/g, ' ').toUpperCase()}
                        </Text>
                      </View>
                      <View style={styles.xpBadge}>
                        <Ionicons name="flash" size={14} color="#FFD700" />
                        <Text style={styles.xpText}>+{mission.xp_reward} XP</Text>
                      </View>
                    </View>

                    <Text style={styles.missionTitle}>{mission.title}</Text>
                    <Text style={styles.missionDescription}>{mission.description}</Text>

                    {!mission.completed && status !== 'running' && status !== 'paused' && (
                      <View style={styles.preStartWrap}>{renderCustomizer(mission)}</View>
                    )}

                    {isTimed && (status === 'running' || status === 'paused') && (
                      <View style={styles.timerWrap}>
                        <View style={styles.timerHeader}>
                          <Ionicons name={isTimerDone ? 'checkmark-circle' : status === 'paused' ? 'pause-circle' : 'time'}
                            size={18} color={isTimerDone ? '#10b981' : status === 'paused' ? '#fbbf24' : theme.primary} />
                          <Text style={[styles.timerText, {
                            color: isTimerDone ? '#10b981' : status === 'paused' ? '#fbbf24' : theme.primary,
                          }]}>
                            {isTimerDone ? 'TIMER COMPLETE'
                              : status === 'paused' ? `PAUSED  ${formatCountdown(remaining)}`
                              : formatCountdown(remaining)}
                          </Text>
                        </View>
                        <View style={styles.progressBarBg}>
                          <LinearGradient
                            colors={isTimerDone ? ['#10b981', '#059669']
                              : status === 'paused' ? ['#fbbf24', '#b45309']
                              : [theme.primary, theme.secondary]}
                            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                            style={[styles.progressBarFill, { width: `${progress}%` }]}
                          />
                        </View>
                      </View>
                    )}

                    {mission.completed ? (
                      <View style={styles.completedBadge}>
                        <Ionicons name="checkmark-circle" size={20} color="#10b981" />
                        <Text style={styles.completedText}>COMPLETED</Text>
                      </View>
                    ) : isTimed ? (
                      renderTimerControls(mission, status, isTimerDone)
                    ) : (
                      <TouchableOpacity testID={`mission-complete-${mission.mission_type}`} style={styles.actionButton}
                        onPress={() => handleCompleteInstant(mission)} disabled={busyId === mission.id} activeOpacity={0.85}>
                        <LinearGradient colors={[theme.primary, theme.secondary]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.actionGradient}>
                          {busyId === mission.id ? <ActivityIndicator color="#000" /> : (
                            <><Ionicons name="checkmark-done" size={18} color="#000" /><Text style={styles.actionText}>COMPLETE</Text></>
                          )}
                        </LinearGradient>
                      </TouchableOpacity>
                    )}
                  </LinearGradient>
                  {canDelete && (
                    <TouchableOpacity testID={`mission-delete-${mission.id}`} onPress={() => handleDeleteRequest(mission)}
                      style={styles.deleteBtn} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} activeOpacity={0.7}>
                      <Ionicons name="close" size={14} color="#cbd6e2" />
                    </TouchableOpacity>
                  )}
                </View>
              </React.Fragment>
            );
          })}
        </View>

        {allMissions.length === 0 && (
          <View style={styles.emptyContainer}>
            <Ionicons name="flash-off" size={48} color="#444" />
            <Text style={styles.emptyText}>No missions available</Text>
          </View>
        )}

        <TouchableOpacity testID="create-custom-mission-btn" onPress={() => setShowCreate(true)} activeOpacity={0.85}
          style={[styles.createBtn, { borderColor: theme.primary + 'aa', shadowColor: theme.primary }]}>
          <View style={[styles.createCorner, styles.createCornerTL, { borderColor: theme.primary }]} />
          <View style={[styles.createCorner, styles.createCornerTR, { borderColor: theme.primary }]} />
          <View style={[styles.createCorner, styles.createCornerBL, { borderColor: theme.primary }]} />
          <View style={[styles.createCorner, styles.createCornerBR, { borderColor: theme.primary }]} />
          <Ionicons name="add-circle-outline" size={20} color={theme.primary} />
          <Text style={[styles.createBtnText, { color: theme.primary }]}>CREATE CUSTOM QUEST</Text>
        </TouchableOpacity>
      </ScrollView>

      {modal && (
        <SystemModal visible={true} title={modal.title} message={modal.message} rows={modal.rows}
          tone={modal.tone} actions={modal.actions} onDismiss={modal.onDismiss ?? closeModal} testID={modal.testID} />
      )}

      <Modal visible={showCreate} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowCreate(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.createOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setShowCreate(false)} />
          <View style={[styles.createFrame, { borderColor: theme.primary + 'aa', shadowColor: theme.primary }]}>
            <View style={[styles.createCorner, styles.createCornerTL, { borderColor: theme.primary }]} />
            <View style={[styles.createCorner, styles.createCornerTR, { borderColor: theme.primary }]} />
            <View style={[styles.createCorner, styles.createCornerBL, { borderColor: theme.primary }]} />
            <View style={[styles.createCorner, styles.createCornerBR, { borderColor: theme.primary }]} />

            <View style={styles.createHeader}>
              <View style={[styles.createIconBox, { borderColor: theme.primary }]}>
                <Ionicons name="add-circle" size={20} color={theme.primary} />
              </View>
              <View style={[styles.createTitleBox, { borderColor: theme.primary }]}>
                <Text style={[styles.createTitle, { color: theme.primary }]}>NEW QUEST</Text>
              </View>
            </View>

            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <Text style={styles.createLabel}>QUEST NAME</Text>
              <TextInput testID="custom-quest-title" value={draft.title}
                onChangeText={(v) => setDraft((d) => ({ ...d, title: v }))}
                placeholder="e.g. Study Biology" placeholderTextColor="#3d4250"
                style={[styles.createInput, { borderColor: theme.primary + '55' }]} maxLength={60} />

              <Text style={styles.createLabel}>DESCRIPTION (OPTIONAL)</Text>
              <TextInput testID="custom-quest-description" value={draft.description}
                onChangeText={(v) => setDraft((d) => ({ ...d, description: v }))}
                placeholder="Short objective..." placeholderTextColor="#3d4250"
                style={[styles.createInput, { borderColor: theme.primary + '55' }]} maxLength={140} multiline />

              <Text style={styles.createLabel}>FORMAT</Text>
              <View style={styles.formatRow}>
                {(['timed', 'instant'] as const).map((f) => {
                  const active = draft.format === f;
                  return (
                    <TouchableOpacity key={f} testID={`custom-quest-format-${f}`}
                      onPress={() => setDraft((d) => ({ ...d, format: f }))}
                      style={[styles.formatChip, {
                        borderColor: theme.primary,
                        backgroundColor: active ? theme.primary + '22' : 'transparent',
                      }]} activeOpacity={0.85}>
                      <Text style={[styles.formatChipText, { color: theme.primary, fontWeight: active ? '900' : '700' }]}>
                        {f.toUpperCase()}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              {draft.format === 'timed' ? (
                <NumberStepper label="DURATION" value={draft.duration_seconds}
                  display={formatDurationLabel(draft.duration_seconds)}
                  onMinus={() => setDraft((d) => ({ ...d, duration_seconds: Math.max(10, d.duration_seconds - getDurationStep(d.duration_seconds)) }))}
                  onPlus={() => setDraft((d) => ({ ...d, duration_seconds: Math.min(43200, d.duration_seconds + getDurationStep(d.duration_seconds)) }))}
                  color={theme.primary} />
              ) : (
                <NumberStepper label="REPS" value={draft.exercise_amount}
                  display={`x${draft.exercise_amount}`}
                  onMinus={() => setDraft((d) => ({ ...d, exercise_amount: Math.max(1, d.exercise_amount - 5) }))}
                  onPlus={() => setDraft((d) => ({ ...d, exercise_amount: Math.min(500, d.exercise_amount + 5) }))}
                  color={theme.primary} />
              )}

              <NumberStepper label="XP REWARD (AUTO)"
                value={computeAutoXp(draft.format, draft.duration_seconds, draft.exercise_amount)}
                display={`+${computeAutoXp(draft.format, draft.duration_seconds, draft.exercise_amount)} XP`}
                onMinus={() => undefined} onPlus={() => undefined} readOnly color="#FFD700" />
            </ScrollView>

            <View style={styles.createActions}>
              <TouchableOpacity testID="custom-quest-cancel" onPress={() => setShowCreate(false)}
                style={[styles.createActionBtn, { borderColor: '#3d4250' }]} activeOpacity={0.85}>
                <Text style={[styles.createActionText, { color: '#7a8fa6' }]}>CANCEL</Text>
              </TouchableOpacity>
              <TouchableOpacity testID="custom-quest-create" onPress={createCustomMission}
                style={[styles.createActionBtn, {
                  borderColor: theme.primary, backgroundColor: theme.primary + '1a',
                  shadowColor: theme.primary, shadowOpacity: 0.6, shadowRadius: 8,
                  shadowOffset: { width: 0, height: 0 }, elevation: 6, flex: 1.4,
                }]} activeOpacity={0.85}>
                <Text style={[styles.createActionText, { color: '#e9f7ff' }]}>CREATE QUEST</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </>
  );
}

function SectionHeader({ label, caption, color }: { label: string; caption?: string; color: string; }) {
  return (
    <View style={styles.sectionHeaderWrap}>
      <View style={[styles.sectionHeaderLine, { backgroundColor: color + '55' }]} />
      <View style={[styles.sectionHeaderTitleBox, { borderColor: color, shadowColor: color }]}>
        <Ionicons name="alert" size={12} color={color} />
        <Text style={[styles.sectionHeaderText, { color }]}>{label}</Text>
      </View>
      {caption ? <Text style={[styles.sectionHeaderCaption, { color: color + 'aa' }]}>{caption}</Text> : null}
      <View style={[styles.sectionHeaderLine, { backgroundColor: color + '55' }]} />
    </View>
  );
}

function NumberStepper({ label, display, onMinus, onPlus, color, readOnly }: {
  label: string; value: number; display: string; onMinus: () => void; onPlus: () => void; color: string; readOnly?: boolean;
}) {
  return (
    <View style={styles.createStepperRow}>
      <Text style={styles.createLabel}>{label}</Text>
      <View style={[styles.createStepperGroup, {
        borderColor: color + '55',
        backgroundColor: readOnly ? 'rgba(255,215,0,0.06)' : '#0a0f1c',
      }]}>
        {!readOnly && (
          <TouchableOpacity onPress={onMinus} style={styles.stepperBtn} activeOpacity={0.7}>
            <Ionicons name="remove" size={16} color="#fff" />
          </TouchableOpacity>
        )}
        <Text style={[styles.stepperValue, readOnly && { color, paddingHorizontal: 16 }]}>{display}</Text>
        {!readOnly && (
          <TouchableOpacity onPress={onPlus} style={styles.stepperBtn} activeOpacity={0.7}>
            <Ionicons name="add" size={16} color="#fff" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

function ControlButton({ testID, icon, label, color, onPress, busy, flex, outlined }: {
  testID: string; icon: any; label: string; color: string; onPress: () => void; busy: boolean; flex: number; outlined?: boolean;
}) {
  return (
    <TouchableOpacity testID={testID}
      style={[styles.controlBtn, { flex },
        outlined ? { borderColor: color, borderWidth: 1.2, backgroundColor: '#0a0a12' } : { backgroundColor: color }]}
      onPress={onPress} disabled={busy} activeOpacity={0.85}>
      {busy ? <ActivityIndicator color={outlined ? color : '#000'} /> : (
        <>
          <Ionicons name={icon} size={16} color={outlined ? color : '#000'} />
          <Text style={[styles.controlText, { color: outlined ? color : '#000' }]}>{label}</Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0a' },
  content: { padding: 20, paddingTop: 60, paddingBottom: 40 },
  loadingContainer: { flex: 1, backgroundColor: '#0a0a0a', justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 },
  subtitle: { fontSize: 12, color: '#666', letterSpacing: 2, fontWeight: '600' },
  title: { fontSize: 30, fontWeight: '900', letterSpacing: 3, marginTop: 2 },
  progressBadge: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#15151c', borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  progressText: { fontSize: 14, fontWeight: '900', color: '#fff' },
  missionsContainer: { gap: 16 },
  missionCard: { borderRadius: 16, overflow: 'hidden', borderWidth: 1.5, position: 'relative' },
  glow: { ...StyleSheet.absoluteFillObject, borderRadius: 16, borderWidth: 1.5, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 18, elevation: 12 },
  mandatoryBg: { ...StyleSheet.absoluteFillObject, opacity: 0.45 },
  mandatoryBgImage: { width: '100%', height: '100%' },
  mandatoryScrim: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(6,2,3,0.35)' },
  missionGradient: { padding: 18 },
  missionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  categoryBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 12, maxWidth: '70%' },
  categoryText: { fontSize: 10, fontWeight: '700', letterSpacing: 1.2 },
  xpBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  xpText: { fontSize: 13, fontWeight: '700', color: '#FFD700' },
  missionTitle: { fontSize: 19, fontWeight: '800', color: '#fff', marginBottom: 6 },
  missionDescription: { fontSize: 14, color: '#8d8d99', marginBottom: 14, lineHeight: 20 },
  preStartWrap: { backgroundColor: '#0f0f17', borderRadius: 12, padding: 12, marginBottom: 14, borderWidth: 1, borderColor: '#1f1f2a', gap: 12 },
  customizeWrap: { gap: 10 },
  stepperRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  stepperLabel: { fontSize: 11, fontWeight: '800', letterSpacing: 1.4, color: '#8d8d99' },
  stepperGroup: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#15151c', borderRadius: 10, borderWidth: 1, borderColor: '#222', overflow: 'hidden' },
  stepperBtn: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  stepperValue: { minWidth: 70, textAlign: 'center', color: '#fff', fontWeight: '900', fontSize: 13, fontVariant: ['tabular-nums'], paddingHorizontal: 6 },
  timerWrap: { marginBottom: 14 },
  timerHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  timerText: { fontSize: 18, fontWeight: '900', letterSpacing: 1, fontVariant: ['tabular-nums'] },
  progressBarBg: { height: 8, backgroundColor: '#1f1f2a', borderRadius: 4, overflow: 'hidden' },
  progressBarFill: { height: '100%', borderRadius: 4 },
  actionButton: { borderRadius: 10, overflow: 'hidden' },
  actionGradient: { flexDirection: 'row', padding: 14, alignItems: 'center', justifyContent: 'center', gap: 8 },
  actionText: { fontSize: 14, fontWeight: '900', color: '#000', letterSpacing: 1.5 },
  controlsRow: { flexDirection: 'row', gap: 8 },
  controlBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, borderRadius: 10 },
  controlText: { fontSize: 12, fontWeight: '900', letterSpacing: 1 },
  completedBadge: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 12, backgroundColor: '#10b98122', borderRadius: 10 },
  completedText: { fontSize: 14, fontWeight: '900', color: '#10b981', letterSpacing: 1.5 },
  emptyContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },
  emptyText: { fontSize: 16, color: '#666', marginTop: 16 },
  createBtn: { marginTop: 20, paddingVertical: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, borderWidth: 1, backgroundColor: 'rgba(92,195,255,0.06)', borderRadius: 4, shadowOpacity: 0.6, shadowRadius: 14, shadowOffset: { width: 0, height: 0 }, elevation: 6, position: 'relative' },
  createBtnText: { fontSize: 12, fontWeight: '900', letterSpacing: 2.2 },
  createCorner: { position: 'absolute', width: 12, height: 12 },
  createCornerTL: { top: -1, left: -1, borderTopWidth: 2, borderLeftWidth: 2 },
  createCornerTR: { top: -1, right: -1, borderTopWidth: 2, borderRightWidth: 2 },
  createCornerBL: { bottom: -1, left: -1, borderBottomWidth: 2, borderLeftWidth: 2 },
  createCornerBR: { bottom: -1, right: -1, borderBottomWidth: 2, borderRightWidth: 2 },
  createOverlay: { flex: 1, backgroundColor: 'rgba(2,6,14,0.85)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20 },
  createFrame: { width: '100%', maxWidth: 440, maxHeight: '88%', borderWidth: 1, borderRadius: 2, backgroundColor: 'rgba(6,12,24,0.97)', padding: 22, shadowOpacity: 0.95, shadowRadius: 26, shadowOffset: { width: 0, height: 0 }, elevation: 16 },
  createHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 20 },
  createIconBox: { width: 40, height: 40, borderWidth: 1, borderRadius: 2, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(92,195,255,0.08)' },
  createTitleBox: { flex: 1, borderWidth: 1, borderRadius: 2, paddingVertical: 9, paddingHorizontal: 14, backgroundColor: 'rgba(92,195,255,0.08)' },
  createTitle: { fontSize: 15, fontWeight: '900', letterSpacing: 3.2 },
  createLabel: { color: '#7a8fa6', fontSize: 10, fontWeight: '800', letterSpacing: 1.8, marginBottom: 8, marginTop: 14 },
  createInput: { backgroundColor: '#070d1a', borderWidth: 1, borderRadius: 2, paddingHorizontal: 14, paddingVertical: 11, color: '#e9f7ff', fontSize: 14, fontWeight: '600', letterSpacing: 0.3, minHeight: 44 },
  formatRow: { flexDirection: 'row', gap: 8 },
  formatChip: { flex: 1, paddingVertical: 11, borderWidth: 1, borderRadius: 2, alignItems: 'center' },
  formatChipText: { fontSize: 11, letterSpacing: 1.8 },
  createStepperRow: { marginTop: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  createStepperGroup: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#070d1a', borderWidth: 1, borderRadius: 2, overflow: 'hidden' },
  createActions: { flexDirection: 'row', gap: 10, marginTop: 22 },
  createActionBtn: { flex: 1, borderWidth: 1, borderRadius: 2, paddingVertical: 13, alignItems: 'center', justifyContent: 'center' },
  createActionText: { fontSize: 12, fontWeight: '900', letterSpacing: 2.2 },
  deleteBtn: { position: 'absolute', top: 8, right: 8, width: 26, height: 26, borderRadius: 13, borderWidth: 1, borderColor: '#3d4250', backgroundColor: 'rgba(10,15,28,0.85)', alignItems: 'center', justifyContent: 'center', zIndex: 5 },
  sectionHeaderWrap: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4, marginTop: 4, marginBottom: 2 },
  sectionHeaderLine: { flex: 1, height: 1 },
  sectionHeaderTitleBox: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderRadius: 2, shadowOpacity: 0.6, shadowRadius: 6, shadowOffset: { width: 0, height: 0 }, elevation: 4 },
  sectionHeaderText: { fontSize: 11, fontWeight: '900', letterSpacing: 2 },
  sectionHeaderCaption: { fontSize: 9, fontWeight: '700', letterSpacing: 1.2 },
});