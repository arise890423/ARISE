import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/context/AuthContext';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { HunterAvatar } from '../../src/components/HunterAvatar';
import {
  THEME_COLORS,
  AVATAR_STYLES,
  BACKGROUND_STYLES,
  getBackgroundStyle,
  getThemeColor,
  getRankColor,
  getAvatarStyle,
} from '../../src/utils/theme';

const BACKEND_URL = "https://project-arise-1.onrender.com";

export default function Profile() {
  const { user, token, logout, updateUser } = useAuth();
  const router = useRouter();
  const theme = getThemeColor(user?.theme_color);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await logout();
          router.replace('/(auth)/login');
        },
      },
    ]);
  };

  const applyCustomization = async (
    update: {
  theme_color?: string;
  avatar_style?: string;
  background_style?: string;
},
  ) => {
    if (!token || !user) return;
    setSaving(true);
    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(update),
      });
      if (response.ok) {
        const data = await response.json();
        await updateUser(data);
      } else {
        Alert.alert('Error', 'Failed to update profile');
      }
    } catch (e) {
      Alert.alert('Error', 'Failed to connect to server');
    } finally {
      setSaving(false);
    }
  };

  if (!user) return null;

  const currentAvatar = getAvatarStyle(user.avatar_style);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Profile Header */}
      <View style={styles.header}>
        <HunterAvatar
          username={user.username}
          rank={user.rank}
          avatarStyle={user.avatar_style}
          size={110}
        />
        <Text style={styles.username}>{user.username}</Text>
        <Text style={[styles.avatarName, { color: theme.primary }]}>
          {currentAvatar.name}
        </Text>
        <Text style={styles.avatarDesc}>&ldquo;{currentAvatar.description}&rdquo;</Text>
      </View>

      {/* Rank Badge */}
      <View style={styles.rankBadge}>
        <LinearGradient
          colors={[getRankColor(user.rank), '#000']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.rankGradient}
        >
          <Text style={styles.rankText}>{user.rank} RANK HUNTER</Text>
        </LinearGradient>
      </View>

      {/* Stats Grid */}
      <View style={styles.statsGrid}>
        <View style={[styles.statCard, { borderColor: theme.primary + '33' }]}>
          <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.statGradient}>
            <Ionicons name="trending-up" size={22} color={theme.primary} />
            <Text style={styles.statValue}>{user.level}</Text>
            <Text style={styles.statLabel}>LEVEL</Text>
          </LinearGradient>
        </View>
        <View style={[styles.statCard, { borderColor: theme.primary + '33' }]}>
          <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.statGradient}>
            <Ionicons name="flash" size={22} color="#FFD700" />
            <Text style={styles.statValue}>{user.xp}</Text>
            <Text style={styles.statLabel}>TOTAL XP</Text>
          </LinearGradient>
        </View>
        <View style={[styles.statCard, { borderColor: theme.primary + '33' }]}>
          <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.statGradient}>
            <Ionicons name="flame" size={22} color="#ff6b00" />
            <Text style={styles.statValue}>{user.streak}</Text>
            <Text style={styles.statLabel}>STREAK</Text>
          </LinearGradient>
        </View>
        <View style={[styles.statCard, { borderColor: theme.primary + '33' }]}>
          <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.statGradient}>
            <Ionicons name="checkmark-done" size={22} color="#10b981" />
            <Text style={styles.statValue}>{user.total_missions_completed}</Text>
            <Text style={styles.statLabel}>COMPLETED</Text>
          </LinearGradient>
        </View>
      </View>

      {/* Current Arc */}
      <View style={[styles.arcCard, { borderColor: theme.primary + '33' }]}>
        <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.arcGradient}>
          <Text style={styles.arcLabel}>CURRENT ARC</Text>
          <Text style={[styles.arcTitle, { color: theme.primary }]}>{user.current_arc}</Text>
          <Text style={styles.arcDescription}>
            Continue your journey to reach new heights
          </Text>
        </LinearGradient>
      </View>

      {/* Customization toggle */}
      <TouchableOpacity
        testID="toggle-customization-button"
        style={[styles.editButton, { borderColor: theme.primary }]}
        onPress={() => setEditing(!editing)}
        activeOpacity={0.85}
      >
        <Ionicons
          name={editing ? 'close' : 'color-palette'}
          size={18}
          color={theme.primary}
        />
        <Text style={[styles.editText, { color: theme.primary }]}>
          {editing ? 'HIDE CUSTOMIZATION' : 'CUSTOMIZE APPEARANCE'}
        </Text>
      </TouchableOpacity>

      {editing && (
        <>
          {/* Avatar Styles */}
          <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
            <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
              <Text style={[styles.cardTitle, { color: theme.primary }]}>HUNTER STYLE</Text>
              <View style={styles.avatarGrid}>
                {AVATAR_STYLES.map((style) => {
                  const active = style.key === user.avatar_style;
                  return (
                    <TouchableOpacity
                      key={style.key}
                      testID={`avatar-${style.key}`}
                      style={[
                        styles.avatarTile,
                        active && {
                          borderColor: theme.primary,
                          backgroundColor: theme.primary + '11',
                        },
                      ]}
                      onPress={() => applyCustomization({ avatar_style: style.key })}
                      disabled={saving}
                      activeOpacity={0.8}
                    >
                      <HunterAvatar
                        username={user.username}
                        rank={user.rank}
                        avatarStyle={style.key}
                        size={56}
                        showBorder={false}
                      />
                      <Text style={styles.avatarTileName}>{style.name}</Text>
                      {active && (
                        <View style={[styles.activeDot, { backgroundColor: theme.primary }]}>
                          <Ionicons name="checkmark" size={12} color="#000" />
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            </LinearGradient>
          </View>

          {/* Color Themes */}
          <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
            <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
              <Text style={[styles.cardTitle, { color: theme.primary }]}>NEON THEME</Text>
              <View style={styles.colorRow}>
                {THEME_COLORS.map((color) => {
                  const active = color.key === user.theme_color;
                  return (
                    <TouchableOpacity
                      key={color.key}
                      testID={`theme-${color.key}`}
                      style={[
                        styles.colorTile,
                        active && {
                          borderColor: color.primary,
                          borderWidth: 3,
                          shadowColor: color.glow,
                        },
                      ]}
                      onPress={() => applyCustomization({ theme_color: color.key })}
                      disabled={saving}
                      activeOpacity={0.8}
                    >
                      <LinearGradient
                        colors={[color.primary, color.secondary]}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                        style={styles.colorSwatch}
                      >
                        {active && <Ionicons name="checkmark" size={20} color="#000" />}
                      </LinearGradient>
                      <Text style={styles.colorName}>{color.name}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              {saving && (
                <View style={styles.savingIndicator}>
                  <ActivityIndicator size="small" color={theme.primary} />
                  <Text style={styles.savingText}>Saving...</Text>
                </View>
              )}
            </LinearGradient>
          </View>
  
{/* Background Selection */}
<View style={[styles.card, { borderColor: theme.primary + '33' }]}>
  <LinearGradient
    colors={['#15151c', '#0a0a12']}
    style={styles.cardGradient}
  >
    <Text
      style={[styles.cardTitle, { color: theme.primary }]}
    >
      BACKGROUND
    </Text>

    <View style={styles.avatarGrid}>
      {BACKGROUND_STYLES.map((bg) => {
        const active =
          bg.key === user.background_style;

        return (
          <TouchableOpacity
            key={bg.key}
            style={[
              styles.avatarTile,
              active && {
                borderColor: theme.primary,
                backgroundColor:
                  theme.primary + '11',
              },
            ]}
            onPress={() =>
              applyCustomization({
                background_style: bg.key,
              } as any)
            }
            disabled={saving}
            activeOpacity={0.8}
          >
            <Image
              source={bg.image}
              style={{
                width: 72,
                height: 72,
                borderRadius: 10,
              }}
              resizeMode="cover"
            />

            <Text style={styles.avatarTileName}>
              {bg.name}
            </Text>

            {active && (
              <View
                style={[
                  styles.activeDot,
                  {
                    backgroundColor:
                      theme.primary,
                  },
                ]}
              >
                <Ionicons
                  name="checkmark"
                  size={12}
                  color="#000"
                />
              </View>
            )}
          </TouchableOpacity>
        );
      })}
    </View>
  </LinearGradient>
</View>
        </>
      )}
      {/* Achievements Section */}
      <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
        <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
          <Text style={[styles.cardTitle, { color: theme.primary }]}>ACHIEVEMENTS</Text>
          <View style={styles.achievementRow}>
            <Ionicons name="star" size={28} color={user.level >= 10 ? '#FFD700' : '#444'} />
            <View style={styles.achievementInfo}>
              <Text
                style={[
                  styles.achievementTitle,
                  user.level < 10 && { color: '#555' },
                ]}
              >
                First Awakening
              </Text>
              <Text style={styles.achievementDesc}>Reach Level 10</Text>
            </View>
          </View>
          <View style={styles.achievementRow}>
            <Ionicons name="trophy" size={28} color={user.streak >= 7 ? '#FFD700' : '#444'} />
            <View style={styles.achievementInfo}>
              <Text
                style={[
                  styles.achievementTitle,
                  user.streak < 7 && { color: '#555' },
                ]}
              >
                Week Warrior
              </Text>
              <Text style={styles.achievementDesc}>Maintain 7-day streak</Text>
            </View>
          </View>
          <View style={styles.achievementRow}>
            <Ionicons
              name="medal"
              size={28}
              color={user.total_missions_completed >= 50 ? '#FFD700' : '#444'}
            />
            <View style={styles.achievementInfo}>
              <Text
                style={[
                  styles.achievementTitle,
                  user.total_missions_completed < 50 && { color: '#555' },
                ]}
              >
                Mission Master
              </Text>
              <Text style={styles.achievementDesc}>Complete 50 missions</Text>
            </View>
          </View>
        </LinearGradient>
      </View>

      {/* Logout Button */}
      <TouchableOpacity
        testID="logout-button"
        style={styles.logoutButton}
        onPress={handleLogout}
        activeOpacity={0.85}
      >
        <Ionicons name="log-out" size={20} color="#ef4444" />
        <Text style={styles.logoutText}>LOGOUT</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0a' },
  content: { padding: 20, paddingTop: 60, paddingBottom: 40 },
  header: { alignItems: 'center', marginBottom: 24 },
  username: {
    fontSize: 26,
    fontWeight: '900',
    color: '#fff',
    letterSpacing: 2,
    marginTop: 16,
  },
  avatarName: { fontSize: 13, fontWeight: '700', letterSpacing: 2, marginTop: 4 },
  avatarDesc: { fontSize: 12, color: '#666', marginTop: 4, fontStyle: 'italic' },
  rankBadge: { borderRadius: 14, overflow: 'hidden', marginBottom: 24 },
  rankGradient: { padding: 16, alignItems: 'center' },
  rankText: { fontSize: 18, fontWeight: '900', color: '#fff', letterSpacing: 3 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  statCard: { width: '48%', borderRadius: 12, overflow: 'hidden', borderWidth: 1 },
  statGradient: { padding: 18, alignItems: 'center' },
  statValue: { fontSize: 26, fontWeight: '900', color: '#fff', marginTop: 6 },
  statLabel: { fontSize: 10, color: '#666', marginTop: 2, letterSpacing: 1 },
  arcCard: { borderRadius: 12, overflow: 'hidden', marginBottom: 20, borderWidth: 1 },
  arcGradient: { padding: 20, alignItems: 'center' },
  arcLabel: { fontSize: 11, color: '#666', letterSpacing: 2 },
  arcTitle: { fontSize: 22, fontWeight: '900', marginTop: 6, marginBottom: 6 },
  arcDescription: { fontSize: 13, color: '#888', textAlign: 'center' },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    marginBottom: 20,
    backgroundColor: '#0f0f17',
  },
  editText: { fontSize: 13, fontWeight: '900', letterSpacing: 1.5 },
  card: { borderRadius: 12, overflow: 'hidden', marginBottom: 20, borderWidth: 1 },
  cardGradient: { padding: 18 },
  cardTitle: { fontSize: 13, fontWeight: '700', letterSpacing: 2, marginBottom: 16 },
  avatarGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 10 },
  avatarTile: {
    width: '31%',
    alignItems: 'center',
    padding: 10,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#222',
    marginBottom: 10,
    position: 'relative',
  },
  avatarTileName: {
    fontSize: 11,
    color: '#aaa',
    marginTop: 8,
    textAlign: 'center',
    fontWeight: '700',
  },
  activeDot: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 8 },
  colorTile: {
    width: '18%',
    alignItems: 'center',
    padding: 6,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#222',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
  },
  colorSwatch: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  colorName: { fontSize: 9, color: '#888', marginTop: 6, textAlign: 'center', fontWeight: '600' },
  savingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 14,
  },
  savingText: { fontSize: 12, color: '#666' },
  achievementRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 14 },
  achievementInfo: { flex: 1 },
  achievementTitle: { fontSize: 15, fontWeight: '700', color: '#fff' },
  achievementDesc: { fontSize: 12, color: '#666', marginTop: 2 },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#15151c',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#ef4444',
    padding: 16,
    marginTop: 8,
    marginBottom: 20,
  },
  logoutText: { fontSize: 15, fontWeight: '800', color: '#ef4444', letterSpacing: 2 },
});
