import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/context/AuthContext';
import { Ionicons } from '@expo/vector-icons';
import { getThemeColor, getRankColor } from '../../src/utils/theme';
import { ActivityGraph } from '../../src/components/ActivityGraph';

const BACKEND_URL = "https://project-arise-1.onrender.com";

interface DailyStat {
  date: string;
  missions_completed: number;
  xp_gained: number;
}

interface Stats {
  daily_stats: DailyStat[];
  week_total_missions: number;
  week_total_xp: number;
  consistency_percentage: number;
}

export default function Progress() {
  const { user, token } = useAuth();
  const theme = getThemeColor(user?.theme_color);
  const [stats, setStats] = useState<Stats | null>(null);
  const [graphMetric, setGraphMetric] = useState<'missions' | 'xp'>('missions');
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) loadStats();
  }, [token]);

  const loadStats = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/progress/stats`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Stats error', e);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStats();
    setRefreshing(false);
  };

  if (!user) return null;

const xpProgress = (() => {
  const xpNeeded = 100 * user.level;

  // Total XP required before reaching current level
  let totalXPBeforeLevel = 0;
  for (let i = 1; i < user.level; i++) {
    totalXPBeforeLevel += 100 * i;
  }

  // XP progress inside current level
  const currentLevelXP = user.xp - totalXPBeforeLevel;

  return {
    // Progress bar values
    current: currentLevelXP,
    needed: xpNeeded,
    percentage: (currentLevelXP / xpNeeded) * 100,

    // Actual total XP earned
    totalXP: user.xp,
  };
})();
  const milestones = [
    { level: 10, rank: 'D', arc: 'Discipline Arc', achieved: user.level >= 10 },
    { level: 20, rank: 'C', arc: 'Discipline Arc', achieved: user.level >= 20 },
    { level: 30, rank: 'B', arc: 'Warrior Arc', achieved: user.level >= 30 },
    { level: 40, rank: 'A', arc: 'Elite Arc', achieved: user.level >= 40 },
    { level: 50, rank: 'S', arc: 'Monarch Arc', achieved: user.level >= 50 },
  ];

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />
      }
    >
      <Text style={[styles.title, { color: theme.primary }]}>PROGRESSION</Text>

      {/* Current Status */}
      <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
        <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
          <Text style={[styles.cardTitle, { color: theme.primary }]}>CURRENT STATUS</Text>

          <View style={styles.statusRow}>
            <View style={styles.statusItem}>
              <Text style={styles.statusLabel}>LEVEL</Text>
              <Text style={styles.statusValue}>{user.level}</Text>
            </View>
            <View style={styles.statusItem}>
              <Text style={styles.statusLabel}>RANK</Text>
              <Text style={[styles.statusValue, { color: getRankColor(user.rank) }]}>
                {user.rank}
              </Text>
            </View>
            <View style={styles.statusItem}>
              <Text style={styles.statusLabel}>STREAK</Text>
              <Text style={styles.statusValue}>{user.streak}</Text>
            </View>
          </View>

          <View style={styles.xpSection}>
            <Text style={styles.xpLabel}>XP TO NEXT LEVEL</Text>
            <Text style={[styles.xpNumbers, { color: theme.primary }]}>
              {Math.floor(xpProgress.current)} / {xpProgress.needed} XP
            </Text>
            <View style={styles.progressBar}>
              <LinearGradient
                colors={[theme.primary, theme.secondary]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.progressFill, { width: `${xpProgress.percentage}%` }]}
              />
            </View>
          </View>
        </LinearGradient>
      </View>

      {/* Weekly Activity Graph */}
      <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
        <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
          <View style={styles.graphHeader}>
            <Text style={[styles.cardTitle, { color: theme.primary, marginBottom: 0 }]}>
              7-DAY ACTIVITY
            </Text>
            <View style={styles.toggleRow}>
              <Text
                onPress={() => setGraphMetric('missions')}
                style={[
                  styles.togglePill,
                  graphMetric === 'missions' && {
                    backgroundColor: theme.primary + '22',
                    color: theme.primary,
                    borderColor: theme.primary,
                  },
                ]}
              >
                MISSIONS
              </Text>
              <Text
                onPress={() => setGraphMetric('xp')}
                style={[
                  styles.togglePill,
                  graphMetric === 'xp' && {
                    backgroundColor: theme.primary + '22',
                    color: theme.primary,
                    borderColor: theme.primary,
                  },
                ]}
              >
                XP
              </Text>
            </View>
          </View>

          {loading ? (
            <ActivityIndicator color={theme.primary} style={{ marginVertical: 30 }} />
          ) : stats ? (
            <>
              <ActivityGraph
                data={stats.daily_stats}
                metric={graphMetric}
                themeColor={user.theme_color}
                height={150}
              />
              <View style={styles.summaryRow}>
                <View style={styles.summaryItem}>
                  <Text style={styles.summaryValue}>{stats.week_total_missions}</Text>
                  <Text style={styles.summaryLabel}>Missions</Text>
                </View>
                <View style={styles.summaryItem}>
                  <Text style={[styles.summaryValue, { color: '#FFD700' }]}>
                    {stats.week_total_xp}
                  </Text>
                  <Text style={styles.summaryLabel}>XP Gained</Text>
                </View>
                <View style={styles.summaryItem}>
                  <Text style={[styles.summaryValue, { color: theme.primary }]}>
                    {stats.consistency_percentage}%
                  </Text>
                  <Text style={styles.summaryLabel}>Consistency</Text>
                </View>
              </View>
            </>
          ) : null}
        </LinearGradient>
      </View>

      {/* Streak Visualization */}
      {stats && (
        <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
          <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
            <Text style={[styles.cardTitle, { color: theme.primary }]}>STREAK FLOW</Text>
            <View style={styles.streakRow}>
              {stats.daily_stats.map((d, i) => {
                const active = d.missions_completed > 0;
                return (
                  <View key={d.date} style={styles.streakNode}>
                    <View
                      style={[
                        styles.streakDot,
                        active && {
                          backgroundColor: '#ff6b00',
                          shadowColor: '#ff6b00',
                          borderColor: '#ff6b00',
                        },
                      ]}
                    >
                      {active && <Ionicons name="flame" size={14} color="#fff" />}
                    </View>
                    {i < stats.daily_stats.length - 1 && (
                      <View
                        style={[styles.streakLine, active && { backgroundColor: '#ff6b0055' }]}
                      />
                    )}
                  </View>
                );
              })}
            </View>
            <View style={styles.streakInfo}>
              <Ionicons name="flame" size={18} color="#ff6b00" />
              <Text style={styles.streakInfoText}>
                {user.streak} day streak — keep the fire alive
              </Text>
            </View>
          </LinearGradient>
        </View>
      )}

      {/* Stats Overview */}
      <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
        <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
          <Text style={[styles.cardTitle, { color: theme.primary }]}>OVERVIEW</Text>

          <View style={styles.statRow}>
            <Ionicons name="flash" size={22} color="#FFD700" />
            <View style={styles.statInfo}>
              <Text style={styles.statLabel}>Total XP Earned</Text>
              <Text style={styles.statValue}>{user.xp}</Text>
            </View>
          </View>
          <View style={styles.statRow}>
            <Ionicons name="checkmark-circle" size={22} color="#10b981" />
            <View style={styles.statInfo}>
              <Text style={styles.statLabel}>Total Missions</Text>
              <Text style={styles.statValue}>{user.total_missions_completed}</Text>
            </View>
          </View>
          <View style={styles.statRow}>
            <Ionicons name="book" size={22} color={theme.primary} />
            <View style={styles.statInfo}>
              <Text style={styles.statLabel}>Current Arc</Text>
              <Text style={styles.statValue}>{user.current_arc}</Text>
            </View>
          </View>
        </LinearGradient>
      </View>

      {/* Milestones */}
      <View style={[styles.card, { borderColor: theme.primary + '33' }]}>
        <LinearGradient colors={['#15151c', '#0a0a12']} style={styles.cardGradient}>
          <Text style={[styles.cardTitle, { color: theme.primary }]}>MILESTONES</Text>
          {milestones.map((m, i) => (
            <View key={i} style={styles.milestoneRow}>
              <View
                style={[
                  styles.milestoneIcon,
                  m.achieved && { borderColor: '#10b981', backgroundColor: '#10b98122' },
                ]}
              >
                <Ionicons
                  name={m.achieved ? 'checkmark' : 'lock-closed'}
                  size={18}
                  color={m.achieved ? '#10b981' : '#555'}
                />
              </View>
              <View style={styles.milestoneInfo}>
                <Text style={[styles.milestoneTitle, !m.achieved && { color: '#555' }]}>
                  Level {m.level} • {m.rank} Rank
                </Text>
                <Text
                  style={[
                    styles.milestoneSubtitle,
                    { color: m.achieved ? theme.primary : '#444' },
                  ]}
                >
                  {m.arc}
                </Text>
              </View>
            </View>
          ))}
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0a' },
  content: { padding: 20, paddingTop: 60, paddingBottom: 40 },
  title: { fontSize: 30, fontWeight: '900', letterSpacing: 3, marginBottom: 24 },
  card: { borderRadius: 16, overflow: 'hidden', marginBottom: 20, borderWidth: 1 },
  cardGradient: { padding: 20 },
  cardTitle: { fontSize: 14, fontWeight: '700', letterSpacing: 2, marginBottom: 18 },
  statusRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 24 },
  statusItem: { alignItems: 'center' },
  statusLabel: { fontSize: 11, color: '#666', letterSpacing: 1.5, marginBottom: 8 },
  statusValue: { fontSize: 32, fontWeight: '900', color: '#fff' },
  xpSection: { paddingTop: 16, borderTopWidth: 1, borderTopColor: '#222' },
  xpLabel: { fontSize: 11, color: '#666', letterSpacing: 1.5, marginBottom: 6 },
  xpNumbers: { fontSize: 16, fontWeight: '800', marginBottom: 10 },
  progressBar: { height: 8, backgroundColor: '#1a1a25', borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%' },
  graphHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  toggleRow: { flexDirection: 'row', gap: 6 },
  togglePill: {
    fontSize: 10,
    fontWeight: '700',
    color: '#666',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#333',
    letterSpacing: 1,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 18,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#222',
  },
  summaryItem: { alignItems: 'center' },
  summaryValue: { fontSize: 22, fontWeight: '900', color: '#fff' },
  summaryLabel: { fontSize: 10, color: '#666', marginTop: 4, letterSpacing: 1 },
  streakRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  streakNode: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  streakDot: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#15151c',
    borderWidth: 2,
    borderColor: '#222',
    alignItems: 'center',
    justifyContent: 'center',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
  },
  streakLine: { flex: 1, height: 2, backgroundColor: '#222' },
  streakInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#222',
  },
  streakInfoText: { fontSize: 12, color: '#888', flex: 1 },
  statRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 14 },
  statInfo: { flex: 1 },
  statLabel: { fontSize: 13, color: '#888', marginBottom: 2 },
  statValue: { fontSize: 16, fontWeight: '700', color: '#fff' },
  milestoneRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14, gap: 14 },
  milestoneIcon: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#15151c',
    borderWidth: 2,
    borderColor: '#333',
    alignItems: 'center',
    justifyContent: 'center',
  },
  milestoneInfo: { flex: 1 },
  milestoneTitle: { fontSize: 15, fontWeight: '700', color: '#fff', marginBottom: 2 },
  milestoneSubtitle: { fontSize: 12 },
});
