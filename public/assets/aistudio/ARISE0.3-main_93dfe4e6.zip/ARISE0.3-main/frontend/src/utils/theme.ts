﻿import { ImageSourcePropType } from 'react-native';

export type ThemeColorKey = 'cyan' | 'crimson' | 'violet' | 'gold' | 'emerald';

export interface ThemeColor {
  key: ThemeColorKey;
  name: string;
  primary: string;
  secondary: string;
  glow: string;
}

export const THEME_COLORS: ThemeColor[] = [
  { key: 'cyan',    name: 'Neon Cyan',      primary: '#00f0ff', secondary: '#0080ff', glow: '#00f0ff' },
  { key: 'crimson', name: 'Crimson Flame',  primary: '#ff3366', secondary: '#cc0033', glow: '#ff3366' },
  { key: 'violet',  name: 'Shadow Violet',  primary: '#a855f7', secondary: '#6d28d9', glow: '#a855f7' },
  { key: 'gold',    name: 'Sovereign Gold', primary: '#fbbf24', secondary: '#d97706', glow: '#fbbf24' },
  { key: 'emerald', name: 'Hunter Emerald', primary: '#10b981', secondary: '#047857', glow: '#10b981' },
];

export const getThemeColor = (key?: string | null): ThemeColor => {
  if (!key || typeof key !== 'string') return THEME_COLORS[0];
  const found = THEME_COLORS.find((t) => t.key === key);
  return found || THEME_COLORS[0];
};

export type RankKey = 'E' | 'D' | 'C' | 'B' | 'A' | 'S' | 'SS' | 'SSS' | 'NATIONAL';

const RANK_COLORS: Record<RankKey, string> = {
  E: '#9ca3af', D: '#10b981', C: '#3b82f6', B: '#a855f7',
  A: '#f97316', S: '#fbbf24', SS: '#ff3366', SSS: '#ff0066',
  NATIONAL: '#ffffff',
};

export const getRankColor = (rank?: string | null): string => {
  if (!rank || typeof rank !== 'string') return '#00f0ff';
  const key = rank.trim().toUpperCase() as RankKey;
  return RANK_COLORS[key] || '#00f0ff';
};

export type AvatarKey = 'default' | 'avatar' | 'rise' | 'arise';

export interface AvatarStyle {
  key: AvatarKey;
  name: string;
  description: string;
  image: ImageSourcePropType;
  isPremium: boolean;
}

const AVATAR_REGISTRY: Record<AvatarKey, AvatarStyle> = {
  default: { key: 'default', name: 'Default Hunter', description: 'The standard awakened soul.',   image: require('../../assets/avatars/default.png'), isPremium: false },
  avatar:  { key: 'avatar',  name: 'Classic Avatar', description: 'A timeless hunter aesthetic.',  image: require('../../assets/avatars/avatar.jpg'),  isPremium: false },
  rise:    { key: 'rise',    name: 'Rise',           description: 'Born from the ashes.',          image: require('../../assets/avatars/rise.png'),    isPremium: false },
  arise:   { key: 'arise',   name: 'Arise',          description: 'Command of the shadows.',       image: require('../../assets/avatars/arise.png'),   isPremium: false },
};

export const AVATAR_STYLES: AvatarStyle[] = Object.values(AVATAR_REGISTRY);

export const getAvatarStyle = (key?: string | null): AvatarStyle => {
  if (!key || typeof key !== 'string') return AVATAR_REGISTRY.default;
  const normalized = key.trim().toLowerCase() as AvatarKey;
  return AVATAR_REGISTRY[normalized] || AVATAR_REGISTRY.default;
};

export const getAllAvatars = (): AvatarStyle[] => Object.values(AVATAR_REGISTRY);
// BACKGROUND STYLES

export type BackgroundKey = 'tuff' | 'violet';

export interface BackgroundStyle {
  key: BackgroundKey;
  name: string;
  description: string;
  image: ImageSourcePropType;
}

const BACKGROUND_REGISTRY: Record<BackgroundKey, BackgroundStyle> = {
  tuff: {
    key: 'tuff',
    name: 'Midnight Tuff',
    description: 'The raw edge of the awakened world.',
    image: require('../../assets/backgrounds/tuff.jpg'),
  },

  violet: {
    key: 'violet',
    name: 'Violet Eclipse',
    description: 'Shadows deepen; neon dreams arise.',
    image: require('../../assets/backgrounds/violet.jpg'),
  },
};

export const BACKGROUND_STYLES: BackgroundStyle[] =
  Object.values(BACKGROUND_REGISTRY);

export const getBackgroundStyle = (
  key?: string | null
): BackgroundStyle => {
  if (!key || typeof key !== 'string') {
    return BACKGROUND_REGISTRY.tuff;
  }

  const normalized = key.trim().toLowerCase() as BackgroundKey;

  return BACKGROUND_REGISTRY[normalized] || BACKGROUND_REGISTRY.tuff;
};
