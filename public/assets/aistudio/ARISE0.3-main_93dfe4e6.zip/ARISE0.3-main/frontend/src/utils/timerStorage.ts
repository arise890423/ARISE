// Timer formatting helper. The actual "persistence" is on the backend
// (mission.started_at), so we just compute the remaining time on the fly
// based on the server's start timestamp + duration. Surviving app close
// is automatic because we use Date.now() math, not setInterval state.

export function formatRemaining(remainingSec: number): string {
  if (remainingSec <= 0) return 'COMPLETE';
  const hours = Math.floor(remainingSec / 3600);
  const minutes = Math.floor((remainingSec % 3600) / 60);
  const seconds = Math.floor(remainingSec % 60);
  if (hours > 0) {
    return `${hours}h ${minutes.toString().padStart(2, '0')}m ${seconds
      .toString()
      .padStart(2, '0')}s`;
  }
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}
