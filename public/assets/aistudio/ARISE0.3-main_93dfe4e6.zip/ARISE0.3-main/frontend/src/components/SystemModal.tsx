import React, { useEffect, useRef } from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * SystemModal — Solo Leveling-inspired holographic system window.
 *
 * Drop-in replacement for Alert.alert in the missions screen.
 * Renders a transparent dark overlay with a glowing cyan-edged panel,
 * animated entrance (fade + scale), four-corner accents, and 1–2
 * action buttons styled as system response boxes (ACCEPT / DECLINE etc.).
 *
 * Performance: a single Modal with native-driver animations. Cheap on Android.
 */

export type SystemModalTone = 'info' | 'warning' | 'success';

export interface SystemModalRow {
  label: string;
  value: string;
  tone?: 'default' | 'highlight' | 'danger';
}

export interface SystemModalAction {
  label: string;
  onPress: () => void;
  tone?: 'primary' | 'secondary' | 'danger';
  testID?: string;
}

export interface SystemModalProps {
  visible: boolean;
  title: string;
  message?: string;
  rows?: SystemModalRow[];
  tone?: SystemModalTone;
  actions: SystemModalAction[];
  onDismiss?: () => void;
  testID?: string;
}

const TONE_COLORS: Record<SystemModalTone, { accent: string; glow: string }> = {
  info:    { accent: '#5cc3ff', glow: '#5cc3ff' },
  warning: { accent: '#ff4d6d', glow: '#ff4d6d' },
  success: { accent: '#10b981', glow: '#10b981' },
};

const ACTION_COLORS: Record<
  NonNullable<SystemModalAction['tone']>,
  { border: string; text: string; bg: string }
> = {
  primary:   { border: '#5cc3ff', text: '#e9f7ff', bg: 'rgba(92,195,255,0.08)' },
  secondary: { border: '#7a8fa6', text: '#cbd6e2', bg: 'transparent' },
  danger:    { border: '#ff4d6d', text: '#ffd1d8', bg: 'rgba(255,77,109,0.08)' },
};

export default function SystemModal({
  visible,
  title,
  message,
  rows,
  tone = 'info',
  actions,
  onDismiss,
  testID,
}: SystemModalProps) {
  const fade = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(0.92)).current;
  const sweep = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(fade, {
          toValue: 1,
          duration: 180,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.spring(scale, {
          toValue: 1,
          friction: 8,
          tension: 90,
          useNativeDriver: true,
        }),
      ]).start();
      Animated.loop(
        Animated.timing(sweep, {
          toValue: 1,
          duration: 2200,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
      ).start();
    } else {
      fade.setValue(0);
      scale.setValue(0.92);
      sweep.setValue(0);
    }
  }, [visible, fade, scale, sweep]);

  const colors = TONE_COLORS[tone];

  const sweepTranslate = sweep.interpolate({
    inputRange: [0, 1],
    outputRange: [-220, 220],
  });

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      statusBarTranslucent
      onRequestClose={onDismiss}
    >
      <Animated.View
        style={[styles.overlay, { opacity: fade }]}
        testID={testID}
      >
        <Pressable style={StyleSheet.absoluteFill} onPress={onDismiss} />
        <Animated.View
          style={[
            styles.panelWrap,
            {
              transform: [{ scale }],
              shadowColor: colors.glow,
            },
          ]}
        >
          {/* Outer glow frame */}
          <View
            style={[
              styles.frame,
              { borderColor: colors.accent + 'aa' },
            ]}
          >
            {/* Four corner accents */}
            <View style={[styles.corner, styles.cornerTL, { borderColor: colors.accent }]} />
            <View style={[styles.corner, styles.cornerTR, { borderColor: colors.accent }]} />
            <View style={[styles.corner, styles.cornerBL, { borderColor: colors.accent }]} />
            <View style={[styles.corner, styles.cornerBR, { borderColor: colors.accent }]} />

            {/* Diagonal sheen sweep */}
            <Animated.View
              pointerEvents="none"
              style={[
                styles.sheen,
                {
                  transform: [
                    { translateX: sweepTranslate },
                    { rotate: '20deg' },
                  ],
                  backgroundColor: colors.accent + '14',
                },
              ]}
            />

            {/* Header */}
            <View style={styles.header}>
              <View style={[styles.iconBox, { borderColor: colors.accent }]}>
                <Ionicons
                  name={
                    tone === 'warning'
                      ? 'warning'
                      : tone === 'success'
                      ? 'shield-checkmark'
                      : 'alert-circle'
                  }
                  size={20}
                  color={colors.accent}
                />
              </View>
              <View
                style={[styles.titleBox, { borderColor: colors.accent }]}
              >
                <Text
                  style={[styles.titleText, { color: colors.accent }]}
                  numberOfLines={1}
                >
                  {title}
                </Text>
              </View>
            </View>

            {/* Body */}
            <View style={styles.body}>
              {message ? (
                <Text style={styles.message}>{message}</Text>
              ) : null}

              {rows && rows.length > 0 && (
                <View style={styles.rows}>
                  {rows.map((r, i) => (
                    <View key={`${r.label}-${i}`} style={styles.row}>
                      <Text style={styles.rowLabel}>{r.label}</Text>
                      <Text
                        style={[
                          styles.rowValue,
                          r.tone === 'highlight' && { color: colors.accent },
                          r.tone === 'danger' && { color: '#ff4d6d' },
                        ]}
                      >
                        {r.value}
                      </Text>
                    </View>
                  ))}
                </View>
              )}
            </View>

            {/* Actions */}
            <View style={styles.actions}>
              {actions.map((a, i) => {
                const c = ACTION_COLORS[a.tone ?? (i === 0 ? 'primary' : 'secondary')];
                return (
                  <TouchableOpacity
                    key={a.label}
                    testID={a.testID}
                    onPress={a.onPress}
                    activeOpacity={0.75}
                    style={[
                      styles.actionBtn,
                      { borderColor: c.border, backgroundColor: c.bg },
                    ]}
                  >
                    <Text
                      style={[styles.actionText, { color: c.text }]}
                      numberOfLines={1}
                    >
                      {a.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        </Animated.View>
      </Animated.View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,14,0.72)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  panelWrap: {
    width: '100%',
    maxWidth: 420,
    shadowOpacity: 0.9,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 0 },
    elevation: 14,
  },
  frame: {
    backgroundColor: 'rgba(5,10,22,0.94)',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 18,
    overflow: 'hidden',
  },
  corner: {
    position: 'absolute',
    width: 14,
    height: 14,
    borderColor: '#5cc3ff',
  },
  cornerTL: { top: -1, left: -1, borderTopWidth: 2, borderLeftWidth: 2 },
  cornerTR: { top: -1, right: -1, borderTopWidth: 2, borderRightWidth: 2 },
  cornerBL: { bottom: -1, left: -1, borderBottomWidth: 2, borderLeftWidth: 2 },
  cornerBR: { bottom: -1, right: -1, borderBottomWidth: 2, borderRightWidth: 2 },
  sheen: {
    position: 'absolute',
    top: -40,
    bottom: -40,
    width: 90,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  iconBox: {
    width: 38,
    height: 38,
    borderWidth: 1,
    borderRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(92,195,255,0.06)',
  },
  titleBox: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 2,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(92,195,255,0.06)',
  },
  titleText: {
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 3,
  },
  body: { marginBottom: 18 },
  message: {
    color: '#e9f7ff',
    fontSize: 15,
    lineHeight: 22,
    letterSpacing: 0.4,
    marginBottom: 12,
  },
  rows: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(92,195,255,0.18)',
    paddingTop: 12,
    gap: 6,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rowLabel: {
    color: '#7a8fa6',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.6,
    textTransform: 'uppercase',
  },
  rowValue: {
    color: '#e9f7ff',
    fontSize: 14,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
    letterSpacing: 0.5,
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionBtn: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 2,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: {
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 2,
  },
});
