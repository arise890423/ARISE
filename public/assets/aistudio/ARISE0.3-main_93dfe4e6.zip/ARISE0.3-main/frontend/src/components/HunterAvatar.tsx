// src/components/HunterAvatar.tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Platform,
  ImageSourcePropType,
} from 'react-native';
import { getAvatarStyle, getRankColor } from '../utils/theme';

export interface HunterAvatarProps {
  username: string;
  rank?: string;
  avatarStyle?: string;
  size?: number;
  showBorder?: boolean;
}

export const HunterAvatar: React.FC<HunterAvatarProps> = ({
  username,
  rank = 'E',
  avatarStyle,
  size = 100,
  showBorder = true,
}) => {
  const [failed, setFailed] = useState(false);

  let image: ImageSourcePropType | null = null;
  try {
    image = getAvatarStyle(avatarStyle).image;
  } catch {
    image = null;
  }

  let borderColor = '#00f0ff';
  try {
    borderColor = getRankColor(rank);
  } catch {
    borderColor = '#00f0ff';
  }

  const initial =
    username && username.trim().length > 0
      ? username.trim().charAt(0).toUpperCase()
      : '?';

  const outer = size + (showBorder ? 8 : 0);
  const showFallback = !image || failed;

  return (
    <View
      style={[
        styles.outer,
        {
          width: outer,
          height: outer,
          borderRadius: outer / 2,
          borderWidth: showBorder ? 3 : 0,
          borderColor,
          shadowColor: borderColor,
        },
      ]}
    >
      <View
        style={[
          styles.inner,
          { width: size, height: size, borderRadius: size / 2 },
        ]}
      >
        {showFallback ? (
          <View
            style={[
              styles.fallback,
              { width: size, height: size, borderRadius: size / 2 },
            ]}
          >
            <Text style={[styles.fallbackText, { fontSize: size * 0.42 }]}>
              {initial}
            </Text>
          </View>
        ) : (
          <Image
            source={image as ImageSourcePropType}
            style={{ width: size, height: size, borderRadius: size / 2 }}
            resizeMode="cover"
            onError={() => setFailed(true)}
          />
        )}
      </View>
    </View>
  );
};

export default HunterAvatar;

const styles = StyleSheet.create({
  outer: {
    alignItems: 'center',
    justifyContent: 'center',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.7,
    shadowRadius: 12,
    ...Platform.select({ android: { elevation: 8 }, default: {} }),
  },
  inner: {
    overflow: 'hidden',
    backgroundColor: '#0a0a0f',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fallback: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0a0a0f',
  },
  fallbackText: {
    color: '#ffffff',
    fontWeight: '900',
  },
});