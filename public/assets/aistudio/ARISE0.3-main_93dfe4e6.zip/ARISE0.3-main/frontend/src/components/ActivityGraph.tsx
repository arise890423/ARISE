import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { getThemeColor } from '../utils/theme';

interface DailyStat {
  date: string;
  missions_completed: number;
  xp_gained: number;
}

interface ActivityGraphProps {
  data: DailyStat[];
  metric: 'missions' | 'xp';
  themeColor?: string;
  height?: number;
}

const DAY_LABELS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

export const ActivityGraph: React.FC<ActivityGraphProps> = ({
  data,
  metric,
  themeColor,
  height = 140,
}) => {
  const theme = getThemeColor(themeColor);
  const values = data.map((d) => (metric === 'missions' ? d.missions_completed : d.xp_gained));
  const maxValue = Math.max(...values, 1);

  return (
    <View style={styles.container}>
      <View style={[styles.barsRow, { height }]}>
        {data.map((stat, index) => {
          const value = metric === 'missions' ? stat.missions_completed : stat.xp_gained;
          const heightPct = (value / maxValue) * 100;
          const barHeight = Math.max((heightPct / 100) * (height - 40), value > 0 ? 8 : 4);
          const dateObj = new Date(stat.date + 'T00:00:00');
          const dayLabel = DAY_LABELS[dateObj.getDay()];
          const isToday = index === data.length - 1;

          return (
            <View key={stat.date} style={styles.barColumn}>
              <Text style={[styles.barValue, value === 0 && styles.barValueMuted]}>
                {value > 0 ? value : ''}
              </Text>
              <View style={[styles.barTrack, { height: height - 40 }]}>
                {value > 0 ? (
                  <LinearGradient
                    colors={[theme.primary, theme.secondary]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 1 }}
                    style={[
                      styles.bar,
                      {
                        height: barHeight,
                        shadowColor: theme.glow,
                      },
                    ]}
                  />
                ) : (
                  <View style={styles.barEmpty} />
                )}
              </View>
              <Text
                style={[
                  styles.dayLabel,
                  isToday && { color: theme.primary, fontWeight: '900' },
                ]}
              >
                {dayLabel}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  barsRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  barColumn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  barTrack: {
    width: '60%',
    backgroundColor: '#15151c',
    borderRadius: 6,
    justifyContent: 'flex-end',
    overflow: 'hidden',
  },
  bar: {
    width: '100%',
    borderRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 6,
  },
  barEmpty: {
    width: '100%',
    height: 4,
    backgroundColor: '#222',
    borderRadius: 6,
  },
  barValue: {
    fontSize: 11,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 6,
    minHeight: 14,
  },
  barValueMuted: {
    color: 'transparent',
  },
  dayLabel: {
    fontSize: 11,
    color: '#666',
    marginTop: 8,
    fontWeight: '600',
    letterSpacing: 1,
  },
});
